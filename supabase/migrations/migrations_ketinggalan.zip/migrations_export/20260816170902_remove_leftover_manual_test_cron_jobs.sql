SELECT cron.unschedule('manual-test-mtf-daily-oneoff');
SELECT cron.unschedule('manual-test-mtf-daily-oneoff2');