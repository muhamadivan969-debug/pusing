-- Section 18.2 v4.2: kolom data_source di signals (IDX_MANUAL / YAHOO_FALLBACK)
alter table public.signals add column if not exists data_source text default 'YAHOO_FALLBACK';

-- tandai asal data di quotes & candles juga, biar bisa dibedain snapshot IDX manual vs Yahoo auto
alter table public.quotes add column if not exists source text default 'YAHOO';
alter table public.candles add column if not exists source text default 'YAHOO';

-- log tiap upload file IDX EOD manual dari admin
create table if not exists public.idx_eod_uploads (
  id uuid primary key default gen_random_uuid(),
  trade_date date not null,
  uploaded_by uuid references auth.users(id),
  file_name text,
  row_count integer,
  matched_count integer,
  unmatched_tickers text[],
  status text not null default 'PROCESSED', -- PROCESSED / FAILED
  error_message text,
  created_at timestamptz not null default now(),
  unique (trade_date)
);

alter table public.idx_eod_uploads enable row level security;

create policy "admin manage idx_eod_uploads" on public.idx_eod_uploads
  for all
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true))
  with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true));
