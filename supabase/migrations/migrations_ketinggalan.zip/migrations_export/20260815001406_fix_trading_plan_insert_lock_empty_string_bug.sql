CREATE OR REPLACE FUNCTION public.enforce_trading_plan_module_lock_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
declare
  v_is_premium boolean;
begin
  select coalesce(is_premium, false) into v_is_premium
  from public.profiles where id = new.user_id;

  if not v_is_premium then
    if NULLIF(trim(new.module_4), '')  is not null or NULLIF(trim(new.module_5), '')  is not null or
       NULLIF(trim(new.module_6), '')  is not null or NULLIF(trim(new.module_7), '')  is not null or
       NULLIF(trim(new.module_8), '')  is not null or NULLIF(trim(new.module_9), '')  is not null or
       NULLIF(trim(new.module_10), '') is not null then
      raise exception 'MODUL_TERKUNCI: modul 4-10 hanya untuk Premium';
    end if;
  end if;
  return new;
end;
$function$;
