
-- Drop dan recreate list_active_signals dengan paywall protection

DROP FUNCTION IF EXISTS public.list_active_signals();

CREATE FUNCTION public.list_active_signals()
RETURNS TABLE (
  id uuid,
  direction text,
  status text,
  created_at timestamptz,
  stock_id uuid,
  ticker text,
  name text,
  entry_price numeric,
  buy_area_low numeric,
  buy_area_high numeric,
  tp1 numeric,
  tp2 numeric,
  stop_loss numeric,
  confidence_score numeric,
  current_price numeric,
  unlocked boolean
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_today date := (now() AT TIME ZONE 'Asia/Jakarta')::date;
  v_is_premium boolean := false;
BEGIN
  IF v_user IS NOT NULL THEN
    SELECT COALESCE(p.is_premium, false) INTO v_is_premium
    FROM public.profiles p WHERE p.id = v_user;
  END IF;

  RETURN QUERY
  SELECT
    s.id,
    s.direction,
    s.status,
    s.created_at,
    st.id AS stock_id,
    st.ticker,
    st.name,
    CASE WHEN (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) THEN s.entry_price ELSE NULL END,
    CASE WHEN (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) THEN s.buy_area_low ELSE NULL END,
    CASE WHEN (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) THEN s.buy_area_high ELSE NULL END,
    CASE WHEN (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) THEN s.tp1 ELSE NULL END,
    CASE WHEN (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) THEN s.tp2 ELSE NULL END,
    CASE WHEN (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) THEN s.stop_loss ELSE NULL END,
    CASE WHEN (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) THEN s.confidence_score ELSE NULL END,
    q.price AS current_price,
    (v_is_premium OR EXISTS (
      SELECT 1 FROM public.signal_unlocks su
      WHERE su.user_id = v_user AND su.stock_id = st.id AND su.unlock_date = v_today
    )) AS unlocked
  FROM public.signals s
  JOIN public.stocks st ON st.id = s.stock_id
  LEFT JOIN public.quotes q ON q.stock_id = st.id
  WHERE s.status IN ('ACTIVE', 'HIT_TP1')
    AND s.superseded_by IS NULL
    AND s.gate_passed = true
  ORDER BY s.created_at DESC;
END;
$$;

-- Pastikan anon dan authenticated bisa akses RPC ini tapi tidak tabel langsung
GRANT EXECUTE ON FUNCTION public.list_active_signals() TO authenticated, anon;
