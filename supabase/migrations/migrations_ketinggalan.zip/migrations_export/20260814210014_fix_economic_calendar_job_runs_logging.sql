CREATE OR REPLACE FUNCTION public.trigger_fetch_economic_calendar()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_url text;
  v_key text;
  v_secret text;
  v_run_id uuid;
  v_req_id bigint;
BEGIN
  v_run_id := public.job_run_start('fetch-economic-calendar');

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';

  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'secret belum lengkap'));
    RETURN;
  END IF;

  SELECT net.http_post(
    url := v_url || '/functions/v1/fetch-economic-calendar',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || v_key,
      'Content-Type', 'application/json',
      'x-worker-secret', v_secret
    ),
    body := '{}'::jsonb,
    timeout_milliseconds := 120000
  ) INTO v_req_id;

  PERFORM public.job_run_finish(v_run_id, 'SUCCESS', jsonb_build_object('net_request_id', v_req_id, 'note', 'dispatched, menunggu reconcile'));
END;
$$;