create or replace view public.signals_public
with (security_invoker = true) as
select
  id,
  stock_id,
  direction,
  timeframe,
  status,
  created_at,
  resolved_at,
  superseded_by,
  signal_tier
from public.signals;

grant select on public.signals_public to anon, authenticated;