
-- Hapus index duplikat (yang constraint notifications_event_id_key sudah cover ini)
DROP INDEX IF EXISTS public.notifications_event_id_unique;
