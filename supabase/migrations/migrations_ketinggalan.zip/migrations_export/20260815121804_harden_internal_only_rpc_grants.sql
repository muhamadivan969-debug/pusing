
-- Fungsi-fungsi ini hanya dipakai internal (cron/trigger) atau sudah dilindungi is_admin di dalamnya,
-- tapi tidak perlu bisa dipanggil langsung via REST RPC oleh anon/authenticated.
-- Revoke EXECUTE publik, tapi tetap izinkan service_role (dipakai oleh cron/trigger internal Supabase).

REVOKE EXECUTE ON FUNCTION public.notify_push_on_new_notification() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.rls_auto_enable() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_generate_signal_reasoning() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_process_corporate_actions() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.process_pending_corporate_actions() FROM anon, authenticated;

-- Fungsi admin: sudah ada guard is_admin di dalam, tapi kita revoke dari anon (tidak perlu login-check pun anon jelas ditolak,
-- ini cuma defense-in-depth supaya tidak muncul di /rest/v1/rpc/ untuk anon).
REVOKE EXECUTE ON FUNCTION public.admin_dashboard_summary() FROM anon;
REVOKE EXECUTE ON FUNCTION public.admin_invalidate_signal(uuid, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.admin_record_corporate_action(uuid, text, date, numeric, text) FROM anon;
