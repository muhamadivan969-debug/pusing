
revoke execute on function public.trigger_signal_pipeline_mtf(text) from anon, authenticated;

revoke execute on function public.protect_signal_immutable_fields() from anon, authenticated;
