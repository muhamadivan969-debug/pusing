
-- 1) CRITICAL FIX: tabel public.signals bisa dibaca langsung oleh siapa saja (anon/authenticated)
--    lewat REST API (/rest/v1/signals?select=*), sehingga entry_price, buy_area, tp1, tp2,
--    stop_loss, confidence_score, ai_reasoning BOCOR tanpa token/premium.
--    Semua RPC (get_signal_for_stock, list_active_signals, get_signal_history) SUDAH benar
--    melakukan masking, tapi table-level RLS "signals readable by all" (qual = true) membuat
--    masking itu bisa dilewati begitu saja lewat query langsung ke tabel.
drop policy if exists "signals readable by all" on public.signals;

revoke select on public.signals from anon, authenticated;

-- Hanya izinkan akses ke kolom aman (ticker context, direction, status, timestamps) lewat RPC.
-- RPC yang sudah ada (SECURITY DEFINER, dimiliki role dengan bypass RLS) tetap berfungsi normal.

-- 2) signal_results juga readable-by-all; per spec 5.12 detail Riwayat Sinyal harus ikut
--    access/token policy. Aggregate stats sudah difilter lewat get_signal_history_stats().
--    Tutup akses langsung, paksa lewat get_signal_history()/get_signal_history_stats().
drop policy if exists "signal_results readable by all" on public.signal_results;
revoke select on public.signal_results from anon, authenticated;

-- 3) Perkecil permukaan serangan: fungsi admin & fungsi internal worker (dipanggil pg_cron
--    sebagai role yang menjalankan cron, biasanya postgres) tidak perlu bisa dieksekusi
--    langsung oleh anon/authenticated lewat /rest/v1/rpc/...
revoke execute on function public.admin_dashboard_summary() from anon, authenticated;
revoke execute on function public.admin_invalidate_signal(uuid, text) from anon, authenticated;
revoke execute on function public.is_current_user_admin() from anon;
revoke execute on function public.trigger_fetch_news() from anon, authenticated;
revoke execute on function public.trigger_master_sync_stock() from anon, authenticated;
revoke execute on function public.trigger_fetch_earnings_calendar() from anon, authenticated;
revoke execute on function public.trigger_fetch_fundamentals() from anon, authenticated;
revoke execute on function public.trigger_generate_trending_reason() from anon, authenticated;
revoke execute on function public.trigger_detect_unusual_activity() from anon, authenticated;
revoke execute on function public.trigger_morning_briefing() from anon, authenticated;
revoke execute on function public.trigger_trending_score() from anon, authenticated;
revoke execute on function public.trigger_ai_task_executor() from anon, authenticated;
revoke execute on function public.trigger_unusual_activity_detection() from anon, authenticated;
revoke execute on function public.reconcile_job_runs() from anon, authenticated;
revoke execute on function public.trigger_signal_pipeline(text) from anon, authenticated;
revoke execute on function public.trigger_fetch_index() from anon, authenticated;
revoke execute on function public.trigger_fetch_quotes() from anon, authenticated;
revoke execute on function public.trigger_fetch_economic_calendar() from anon, authenticated;
revoke execute on function public.expire_grace_subscriptions() from anon, authenticated;
revoke execute on function public.process_corporate_actions() from anon, authenticated;
revoke execute on function public.trigger_fetch_ipo_calendar() from anon, authenticated;
revoke execute on function public.compute_sector_rotation() from anon, authenticated;
revoke execute on function public.trigger_evaluate_signals() from anon, authenticated;
