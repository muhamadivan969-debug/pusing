-- CRITICAL FIX: RLS policy profiles_update_own cuma cek auth.uid()=id tanpa WITH CHECK,
-- artinya user bisa PATCH is_premium/is_admin/is_active/deleted_at miliknya sendiri jadi true
-- lewat REST API langsung (bypass UI), padahal spec 1.5 wajib "Perubahan Premium tidak dilakukan di client".
-- Fix: trigger yang mengunci kolom sensitif ini kecuali request datang dari service_role (server/webhook/backend).

create or replace function public.protect_sensitive_profile_columns()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $$
begin
  if auth.role() <> 'service_role' then
    new.is_premium := old.is_premium;
    new.is_admin := old.is_admin;
    new.is_active := old.is_active;
    new.deleted_at := old.deleted_at;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_protect_sensitive_profile_columns on public.profiles;
create trigger trg_protect_sensitive_profile_columns
before update on public.profiles
for each row
execute function public.protect_sensitive_profile_columns();
