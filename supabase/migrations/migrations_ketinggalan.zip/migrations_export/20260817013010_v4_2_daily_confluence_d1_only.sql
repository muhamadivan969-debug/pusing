CREATE OR REPLACE FUNCTION public.trigger_signal_pipeline_mtf(p_tier text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_url text; v_key text; v_secret text; v_headers jsonb;
  v_run_id uuid; v_req bigint; v_timeframes text[]; v_existing int;
BEGIN
  IF p_tier NOT IN ('daily','swing') THEN
    RAISE EXCEPTION 'tier tidak dikenal: %', p_tier;
  END IF;

  SELECT count(*) INTO v_existing FROM public.mtf_pipeline_runs WHERE tier = p_tier AND status = 'RUNNING';
  IF v_existing > 0 THEN
    RETURN;
  END IF;

  -- Spec v4.2 section 5.2: H1/H4 dihapus dari engine. Daily = D1 saja. Swing tetap D1+W1.
  v_timeframes := CASE WHEN p_tier='daily' THEN ARRAY['D1'] ELSE ARRAY['D1','W1'] END;
  v_run_id := public.job_run_start('signal-pipeline-mtf-' || p_tier);

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason','vault secrets belum diset'));
    RETURN;
  END IF;
  v_headers := jsonb_build_object('Authorization','Bearer '||v_key,'Content-Type','application/json','x-worker-secret',v_secret);

  SELECT net.http_post(
    url := v_url || '/functions/v1/fetch-candles?timeframe=' || v_timeframes[1] || '&offset=0&limit=100',
    headers := v_headers, timeout_milliseconds := 240000
  ) INTO v_req;

  INSERT INTO public.mtf_pipeline_runs(tier, status, stage, timeframes, tf_index, offset_val, pending_request_id, job_run_id, detail)
  VALUES (p_tier, 'RUNNING', 'fetch-candles', v_timeframes, 1, 0, v_req, v_run_id, jsonb_build_object('timeframe', v_timeframes[1]));
END;
$function$
