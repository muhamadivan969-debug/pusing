
-- section 23 & 69: news_events = lapisan event terklasifikasi/dedup di atas raw articles (news)
-- dan mapping issuer (news_issuer_mapping). Satu event bisa berasal dari beberapa artikel duplikat/terkait.
create table if not exists public.news_events (
  id uuid primary key default gen_random_uuid(),
  stock_id uuid references public.stocks(id),
  event_type text,
  impact_classification text check (impact_classification in ('POTENTIALLY_POSITIVE','POTENTIALLY_NEGATIVE','MIXED_UNCLEAR','INFORMATIONAL')),
  primary_article_id uuid references public.news(id),
  related_article_ids uuid[] default '{}',
  evidence_summary text,
  first_seen_at timestamptz not null default now(),
  last_updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists idx_news_events_stock_id on public.news_events(stock_id);
create index if not exists idx_news_events_primary_article on public.news_events(primary_article_id);

alter table public.news_events enable row level security;

create policy "news_events readable by all"
on public.news_events for select to public using (true);
