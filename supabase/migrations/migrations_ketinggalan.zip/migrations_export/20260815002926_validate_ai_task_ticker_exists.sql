
CREATE OR REPLACE FUNCTION public.enforce_ai_task_limits()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE
  v_is_premium boolean;
  v_max_tasks int;
  v_active_count int;
  v_ticker text;
  v_ticker_exists boolean;
BEGIN
  SELECT is_premium INTO v_is_premium FROM public.profiles WHERE id = NEW.user_id;
  v_is_premium := COALESCE(v_is_premium, false);

  IF NOT v_is_premium AND NEW.task_type IN ('LEVEL_RETEST', 'UNUSUAL_VOLUME') THEN
    RAISE EXCEPTION 'AI_TASK_TYPE_REQUIRES_PREMIUM';
  END IF;

  v_max_tasks := CASE WHEN v_is_premium THEN 20 ELSE 3 END;

  IF NEW.is_active THEN
    SELECT count(*) INTO v_active_count
    FROM public.ai_tasks
    WHERE user_id = NEW.user_id AND is_active = true;

    IF v_active_count >= v_max_tasks THEN
      RAISE EXCEPTION 'AI_TASK_LIMIT_REACHED';
    END IF;
  END IF;

  -- Validasi ticker wajib ada di stocks untuk task berbasis harga saham
  IF NEW.task_type IN ('PRICE_ALERT', 'LEVEL_RETEST', 'UNUSUAL_VOLUME') THEN
    v_ticker := NEW.parameters->>'ticker';
    IF v_ticker IS NOT NULL AND trim(v_ticker) <> '' THEN
      SELECT EXISTS(SELECT 1 FROM public.stocks WHERE ticker = upper(v_ticker) AND is_active = true)
        INTO v_ticker_exists;
      IF NOT v_ticker_exists THEN
        RAISE EXCEPTION 'AI_TASK_INVALID_TICKER: %', v_ticker;
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;
