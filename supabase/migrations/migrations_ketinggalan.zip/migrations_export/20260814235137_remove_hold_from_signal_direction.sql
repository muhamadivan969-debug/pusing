-- Pastikan tidak ada baris HOLD tersisa (safety, seharusnya sudah 0)
UPDATE signals SET status = 'INVALIDATED' WHERE direction = 'HOLD' AND status = 'ACTIVE';

-- Perketat constraint: direction hanya boleh BUY atau SELL
ALTER TABLE public.signals DROP CONSTRAINT IF EXISTS signals_direction_check;
ALTER TABLE public.signals ADD CONSTRAINT signals_direction_check CHECK (direction = ANY (ARRAY['BUY'::text, 'SELL'::text]));
