-- Bug kritis: deduct_token() SELALU gagal (error "column reference balance is
-- ambiguous") karena nama kolom token_wallets.balance tabrakan dengan nama
-- output parameter fungsi RETURNS TABLE(balance integer, ...). Ini bikin AI Chat
-- (dan fitur lain yg pakai deduct_token) gagal total setiap kali dipanggil --
-- padahal saldo token user cukup. Perbaikan: kualifikasi semua kolom dengan alias tabel.

CREATE OR REPLACE FUNCTION public.deduct_token(p_type text, p_reference_id uuid DEFAULT NULL::uuid)
RETURNS TABLE(balance integer, already_charged boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
DECLARE
  v_user_id uuid := auth.uid();
  v_wallet_id uuid;
  v_balance integer;
  v_last_reset date;
  v_today_wib date := (now() AT TIME ZONE 'Asia/Jakarta')::date;
  v_is_premium boolean;
  v_daily_grant integer;
  v_existing_id uuid;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;
  IF p_type IS NULL OR p_type = '' THEN
    RAISE EXCEPTION 'INVALID_TYPE';
  END IF;

  IF p_reference_id IS NOT NULL THEN
    SELECT tt.id INTO v_existing_id
    FROM public.token_transactions tt
    JOIN public.token_wallets tw ON tw.id = tt.wallet_id
    WHERE tw.user_id = v_user_id AND tt.reference_id = p_reference_id AND tt.type = p_type
    LIMIT 1;

    IF v_existing_id IS NOT NULL THEN
      SELECT tw.balance INTO v_balance FROM public.token_wallets tw WHERE tw.user_id = v_user_id;
      RETURN QUERY SELECT v_balance, true;
      RETURN;
    END IF;
  END IF;

  SELECT p.is_premium INTO v_is_premium FROM public.profiles p WHERE p.id = v_user_id;
  v_daily_grant := CASE WHEN v_is_premium THEN 50 ELSE 5 END;

  SELECT tw.id, tw.balance, tw.last_reset_date INTO v_wallet_id, v_balance, v_last_reset
  FROM public.token_wallets tw
  WHERE tw.user_id = v_user_id
  FOR UPDATE;

  IF v_wallet_id IS NULL THEN
    INSERT INTO public.token_wallets (user_id, balance, last_reset_date)
    VALUES (v_user_id, v_daily_grant, v_today_wib)
    RETURNING token_wallets.id, token_wallets.balance, token_wallets.last_reset_date
    INTO v_wallet_id, v_balance, v_last_reset;
  ELSIF v_last_reset < v_today_wib THEN
    UPDATE public.token_wallets AS tw
      SET balance = v_daily_grant, last_reset_date = v_today_wib
      WHERE tw.id = v_wallet_id
      RETURNING tw.balance INTO v_balance;
  END IF;

  IF v_balance <= 0 THEN
    RAISE EXCEPTION 'INSUFFICIENT_TOKENS';
  END IF;

  UPDATE public.token_wallets AS tw SET balance = tw.balance - 1
    WHERE tw.id = v_wallet_id RETURNING tw.balance INTO v_balance;

  INSERT INTO public.token_transactions (wallet_id, amount, type, reference_id)
  VALUES (v_wallet_id, -1, p_type, p_reference_id);

  RETURN QUERY SELECT v_balance, false;
END;
$function$;
