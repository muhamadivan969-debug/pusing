REVOKE EXECUTE ON FUNCTION public.protect_idx_manual_candle() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.protect_idx_manual_quote() FROM PUBLIC, anon, authenticated;