-- Hardening: SECURITY DEFINER functions wajib punya search_path tetap,
-- kalau tidak berpotensi search_path hijacking. 6 fungsi ini kelewat.
ALTER FUNCTION public.process_corporate_actions() SET search_path = public;
ALTER FUNCTION public.trigger_fetch_ipo_calendar() SET search_path = public;
ALTER FUNCTION public.reconcile_fetch_ipo_calendar() SET search_path = public;
ALTER FUNCTION public.trigger_generate_trending_reason() SET search_path = public;
ALTER FUNCTION public.trigger_fetch_earnings_calendar() SET search_path = public;
ALTER FUNCTION public.trigger_fetch_fundamentals() SET search_path = public;
