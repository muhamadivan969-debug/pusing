-- Fix: anon & authenticated tidak pernah dapat GRANT SELECT ke tabel signals,
-- sehingga view signals_public (dipakai Home page utk "Sinyal Terbaru") gagal
-- dengan "permission denied for table signals". Kolom sensitif (entry_price,
-- buy_area, tp1, tp2, stop_loss, confidence_score) SENGAJA tidak di-grant di
-- sini supaya tetap terkunci di balik RPC list_active_signals()/get_signal_history()
-- yang mengecek token unlock / premium status.

grant select (
  id, stock_id, direction, timeframe, status,
  created_at, resolved_at, superseded_by
) on public.signals to anon, authenticated;

drop policy if exists "public read of signal metadata" on public.signals;
create policy "public read of signal metadata"
  on public.signals
  for select
  to anon, authenticated
  using (true);
