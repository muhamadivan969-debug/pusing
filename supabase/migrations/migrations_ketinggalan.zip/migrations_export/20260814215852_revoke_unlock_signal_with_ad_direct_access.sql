
-- unlock_signal_with_ad adalah stub sementara (tanpa verifikasi AdMob) yang saat ini
-- bisa dipanggil langsung oleh siapapun yang login, memberi unlock signal gratis
-- tanpa benar-benar nonton iklan. Jalur yang benar adalah admob-ssv edge function ->
-- credit_ad_unlock_verified (sudah dikunci ke service_role, sudah aman).
-- Cabut akses authenticated dari stub ini supaya tidak bisa di-exploit sebelum AdMob SDK terpasang.
REVOKE EXECUTE ON FUNCTION public.unlock_signal_with_ad(uuid) FROM authenticated;
