-- Fix auth.<fn>() re-evaluation per row by wrapping with (select ...)
-- and split ALL-policies that overlap with a dedicated SELECT policy
-- (fixes both auth_rls_initplan and multiple_permissive_policies lints)

-- golden_test_cases
DROP POLICY IF EXISTS golden_test_cases_admin_select ON public.golden_test_cases;
DROP POLICY IF EXISTS golden_test_cases_service_write ON public.golden_test_cases;

CREATE POLICY golden_test_cases_admin_select ON public.golden_test_cases
  FOR SELECT
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true));

CREATE POLICY golden_test_cases_service_insert ON public.golden_test_cases
  FOR INSERT
  WITH CHECK ((select auth.role()) = 'service_role');

CREATE POLICY golden_test_cases_service_update ON public.golden_test_cases
  FOR UPDATE
  USING ((select auth.role()) = 'service_role')
  WITH CHECK ((select auth.role()) = 'service_role');

CREATE POLICY golden_test_cases_service_delete ON public.golden_test_cases
  FOR DELETE
  USING ((select auth.role()) = 'service_role');

-- news_issuer_mapping
DROP POLICY IF EXISTS news_issuer_mapping_select_all ON public.news_issuer_mapping;
DROP POLICY IF EXISTS news_issuer_mapping_service_write ON public.news_issuer_mapping;

CREATE POLICY news_issuer_mapping_select_all ON public.news_issuer_mapping
  FOR SELECT
  USING (true);

CREATE POLICY news_issuer_mapping_service_insert ON public.news_issuer_mapping
  FOR INSERT
  WITH CHECK ((select auth.role()) = 'service_role');

CREATE POLICY news_issuer_mapping_service_update ON public.news_issuer_mapping
  FOR UPDATE
  USING ((select auth.role()) = 'service_role')
  WITH CHECK ((select auth.role()) = 'service_role');

CREATE POLICY news_issuer_mapping_service_delete ON public.news_issuer_mapping
  FOR DELETE
  USING ((select auth.role()) = 'service_role');

-- security_acceptance_checks (single ALL policy, no dedupe needed, just initplan fix)
DROP POLICY IF EXISTS security_acceptance_checks_admin_all ON public.security_acceptance_checks;
CREATE POLICY security_acceptance_checks_admin_all ON public.security_acceptance_checks
  FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true));

-- signal_pipeline_events (already split by cmd, just initplan fix)
DROP POLICY IF EXISTS signal_pipeline_events_admin_select ON public.signal_pipeline_events;
CREATE POLICY signal_pipeline_events_admin_select ON public.signal_pipeline_events
  FOR SELECT
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true));

DROP POLICY IF EXISTS signal_pipeline_events_service_write ON public.signal_pipeline_events;
CREATE POLICY signal_pipeline_events_service_write ON public.signal_pipeline_events
  FOR INSERT
  WITH CHECK ((select auth.role()) = 'service_role');

-- signal_revisions (already split by cmd, just initplan fix)
DROP POLICY IF EXISTS signal_revisions_admin_select ON public.signal_revisions;
CREATE POLICY signal_revisions_admin_select ON public.signal_revisions
  FOR SELECT
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true));

DROP POLICY IF EXISTS signal_revisions_admin_insert ON public.signal_revisions;
CREATE POLICY signal_revisions_admin_insert ON public.signal_revisions
  FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true)
    AND requested_by = (select auth.uid())
  );

DROP POLICY IF EXISTS signal_revisions_service_write ON public.signal_revisions;
CREATE POLICY signal_revisions_service_write ON public.signal_revisions
  FOR UPDATE
  USING ((select auth.role()) = 'service_role')
  WITH CHECK ((select auth.role()) = 'service_role');