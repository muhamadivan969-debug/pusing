
-- Tambah kategori SUBSCRIPTION ke notifications (sebelumnya cuma 6 kategori, belum ada utk billing/renewal)
ALTER TABLE public.notifications DROP CONSTRAINT IF EXISTS notifications_category_check;
ALTER TABLE public.notifications ADD CONSTRAINT notifications_category_check
  CHECK (category = ANY (ARRAY['MARKET','SIGNAL','NEWS','ECONOMIC_EVENT','MORNING_BRIEFING','UNUSUAL_ACTIVITY','SUBSCRIPTION']));

-- Fungsi: kirim notifikasi H-1 sebelum periode langganan berakhir (auto-renew maupun mau habis)
CREATE OR REPLACE FUNCTION public.notify_subscription_renewal_h1()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.notifications (user_id, category, title, body, reference_id, event_id)
  SELECT
    s.user_id,
    'SUBSCRIPTION',
    CASE WHEN s.cancel_at_period_end
      THEN 'Langganan Premium Berakhir Besok'
      ELSE 'Langganan Premium Diperpanjang Besok'
    END,
    CASE WHEN s.cancel_at_period_end
      THEN 'Langganan Premium kamu akan berakhir pada ' || to_char(s.period_end, 'DD Mon YYYY') || ' dan tidak diperpanjang otomatis.'
      ELSE 'Langganan Premium kamu akan diperpanjang otomatis pada ' || to_char(s.period_end, 'DD Mon YYYY') || '.'
    END,
    s.id,
    'sub_renewal_h1:' || s.id || ':' || s.period_end::date
  FROM public.subscriptions s
  JOIN public.notification_preferences np ON np.user_id = s.user_id
  WHERE s.status = 'active'
    AND s.period_end IS NOT NULL
    AND s.period_end::date = (now() AT TIME ZONE 'Asia/Jakarta')::date + INTERVAL '1 day'
    AND np.master_enabled = true
  ON CONFLICT (event_id) DO NOTHING;
END;
$function$;

-- Jadwal: sekali sehari, pagi WIB (00:05 UTC = 07:05 WIB)
SELECT cron.schedule(
  'subscription-renewal-h1-notif',
  '5 0 * * *',
  $$select public.notify_subscription_renewal_h1();$$
);
