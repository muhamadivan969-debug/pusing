-- Drop overload RPC versi lama yang masih rujuk gate_passed/confidence_score
-- (kolom itu sudah tidak ada di tabel signals -- overload ini akan error
-- kalau kepanggil, dan bikin ambigu pemanggilan tanpa argumen).
drop function if exists public.list_active_signals();
drop function if exists public.get_signal_for_stock(uuid);

-- get_signal_history: tambah filter signal_tier + hapus asumsi lama
-- "gate_passed" (kolom sudah tidak ada). Konsisten dgn get_signal_for_stock
-- dan list_active_signals versi baru yang sudah pakai signal_tier.
create or replace function public.get_signal_history(
  p_status text default null,
  p_tier text default null,
  p_days integer default null,
  p_limit integer default 50,
  p_offset integer default 0
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_user uuid := auth.uid();
  v_is_premium boolean := false;
  v_result jsonb;
begin
  if v_user is not null then
    select coalesce(is_premium, false) into v_is_premium from public.profiles where id = v_user;
  end if;

  select jsonb_agg(row_to_json(t)) into v_result from (
    select
      sg.id, st.ticker, st.name as stock_name, sg.direction, sg.timeframe, sg.signal_tier,
      sg.status, sg.created_at, sg.resolved_at, sr.result, sr.r_multiple,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then true else false end as unlocked,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.entry_price else null end as entry_price,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.tp1 else null end as tp1,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.tp2 else null end as tp2,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.stop_loss else null end as stop_loss
    from public.signals sg
    join public.stocks st on st.id = sg.stock_id
    left join public.signal_results sr on sr.signal_id = sg.id
    where sg.status in ('HIT_TP1','HIT_TP2','HIT_SL','HIT_SL_LOCKED','EXPIRED','INVALIDATED')
      and (p_status is null or sg.status = p_status)
      and (p_tier is null or sg.signal_tier = p_tier)
      and (p_days is null or sg.created_at >= now() - (p_days || ' days')::interval)
    order by sg.created_at desc
    limit p_limit offset p_offset
  ) t;

  return coalesce(v_result, '[]'::jsonb);
end;
$$;