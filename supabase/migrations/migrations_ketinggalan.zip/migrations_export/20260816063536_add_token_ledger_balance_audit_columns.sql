
alter table public.token_transactions
  add column if not exists balance_before integer,
  add column if not exists balance_after integer;

create or replace function public.deduct_token(p_type text, p_reference_id uuid DEFAULT NULL::uuid)
 RETURNS TABLE(balance integer, already_charged boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE
  v_user_id uuid := auth.uid();
  v_wallet_id uuid;
  v_balance integer;
  v_balance_before integer;
  v_last_reset date;
  v_today_wib date := (now() AT TIME ZONE 'Asia/Jakarta')::date;
  v_is_premium boolean;
  v_daily_grant integer;
  v_existing_id uuid;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;
  IF p_type IS NULL OR p_type = '' THEN
    RAISE EXCEPTION 'INVALID_TYPE';
  END IF;

  IF p_reference_id IS NOT NULL THEN
    SELECT tt.id INTO v_existing_id
    FROM public.token_transactions tt
    JOIN public.token_wallets tw ON tw.id = tt.wallet_id
    WHERE tw.user_id = v_user_id AND tt.reference_id = p_reference_id AND tt.type = p_type
    LIMIT 1;

    IF v_existing_id IS NOT NULL THEN
      SELECT tw.balance INTO v_balance FROM public.token_wallets tw WHERE tw.user_id = v_user_id;
      RETURN QUERY SELECT v_balance, true;
      RETURN;
    END IF;
  END IF;

  SELECT p.is_premium INTO v_is_premium FROM public.profiles p WHERE p.id = v_user_id;
  v_daily_grant := CASE WHEN v_is_premium THEN 50 ELSE 5 END;

  SELECT tw.id, tw.balance, tw.last_reset_date INTO v_wallet_id, v_balance, v_last_reset
  FROM public.token_wallets tw
  WHERE tw.user_id = v_user_id
  FOR UPDATE;

  IF v_wallet_id IS NULL THEN
    INSERT INTO public.token_wallets (user_id, balance, last_reset_date)
    VALUES (v_user_id, v_daily_grant, v_today_wib)
    RETURNING token_wallets.id, token_wallets.balance, token_wallets.last_reset_date
    INTO v_wallet_id, v_balance, v_last_reset;
  ELSIF v_last_reset < v_today_wib THEN
    UPDATE public.token_wallets AS tw
      SET balance = v_daily_grant, last_reset_date = v_today_wib
      WHERE tw.id = v_wallet_id
      RETURNING tw.balance INTO v_balance;
  END IF;

  IF v_balance <= 0 THEN
    RAISE EXCEPTION 'INSUFFICIENT_TOKENS';
  END IF;

  v_balance_before := v_balance;

  UPDATE public.token_wallets AS tw SET balance = tw.balance - 1
    WHERE tw.id = v_wallet_id RETURNING tw.balance INTO v_balance;

  INSERT INTO public.token_transactions (wallet_id, amount, type, reference_id, balance_before, balance_after)
  VALUES (v_wallet_id, -1, p_type, p_reference_id, v_balance_before, v_balance);

  RETURN QUERY SELECT v_balance, false;
END;
$function$;

create or replace function public.unlock_signal_with_token(p_stock_id uuid, p_idempotency_key uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_user   uuid := auth.uid();
  v_wallet public.token_wallets;
  v_today  date := (now() at time zone 'Asia/Jakarta')::date;
begin
  if v_user is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if exists (
      select 1 from public.token_transactions
      where reference_id = p_idempotency_key and type = 'SIGNAL_UNLOCK'
    ) then
      return jsonb_build_object('status', 'ok', 'already_processed', true);
  end if;

  v_wallet := public.ensure_wallet_current(v_user);

  if exists (
      select 1 from public.signal_unlocks
      where user_id = v_user and stock_id = p_stock_id and unlock_date = v_today
    ) then
      return jsonb_build_object('status', 'ok', 'already_unlocked', true, 'balance', v_wallet.balance);
  end if;

  if v_wallet.balance < 1 then
    raise exception 'INSUFFICIENT_TOKENS';
  end if;

  update public.token_wallets set balance = balance - 1 where id = v_wallet.id;

  insert into public.token_transactions (wallet_id, amount, type, reference_id, balance_before, balance_after)
  values (v_wallet.id, -1, 'SIGNAL_UNLOCK', p_idempotency_key, v_wallet.balance, v_wallet.balance - 1);

  insert into public.signal_unlocks (user_id, stock_id, unlock_date, source)
  values (v_user, p_stock_id, v_today, 'TOKEN')
  on conflict (user_id, stock_id, unlock_date) do nothing;

  return jsonb_build_object('status', 'ok', 'balance', v_wallet.balance - 1);
end;
$function$;
