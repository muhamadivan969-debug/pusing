SELECT cron.unschedule('trending-score');
SELECT cron.unschedule('earnings-calendar-sync');
SELECT cron.unschedule('ipo-calendar-sync');
SELECT cron.unschedule('fundamentals-sync');