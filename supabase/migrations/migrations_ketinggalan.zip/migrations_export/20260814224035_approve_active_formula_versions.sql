
-- Insert row untuk baseline_v7 yang dipakai sinyal aktif tapi belum ada di tabel
INSERT INTO public.signal_engine_versions (formula_version, timeframe, is_approved)
VALUES
  ('baseline_v7', 'D1', true),
  ('baseline_v7', 'H1', true),
  ('baseline_v7', 'H4', true),
  ('baseline_v7', 'W1', true)
ON CONFLICT (formula_version, timeframe) DO UPDATE SET is_approved = true;

-- Update baseline_v6 untuk H1 juga (ada 15 sinyal aktif pakai v6/H1)
INSERT INTO public.signal_engine_versions (formula_version, timeframe, is_approved)
VALUES ('baseline_v6', 'H1', true)
ON CONFLICT (formula_version, timeframe) DO UPDATE SET is_approved = true;

-- Update gate_passed di semua sinyal ACTIVE yang sekarang sudah lulus gate
UPDATE public.signals s
SET gate_passed = true
WHERE s.status = 'ACTIVE'
  AND s.superseded_by IS NULL
  AND EXISTS (
    SELECT 1 FROM public.signal_engine_versions sev
    WHERE sev.formula_version = s.formula_version
      AND sev.timeframe = s.timeframe
      AND sev.is_approved = true
  );
