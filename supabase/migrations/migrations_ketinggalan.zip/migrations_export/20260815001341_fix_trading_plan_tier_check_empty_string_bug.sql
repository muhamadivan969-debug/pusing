-- Bug: trigger enforce_trading_plan_tier() cek "IS NOT NULL", tapi frontend kirim
-- modul 4-10 yang belum diisi sebagai empty string '' (bukan NULL), jadi user Free
-- gagal simpan modul 1-3 juga (error TRADING_PLAN_MODULE_REQUIRES_PREMIUM padahal
-- modul 4-10 sebenarnya kosong). Perbaikan: anggap string kosong/whitespace = kosong.

CREATE OR REPLACE FUNCTION public.enforce_trading_plan_tier()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_is_premium boolean;
BEGIN
  SELECT is_premium INTO v_is_premium FROM public.profiles WHERE id = NEW.user_id;
  IF NOT COALESCE(v_is_premium, false) THEN
    IF NULLIF(trim(NEW.module_4), '')  IS NOT NULL OR NULLIF(trim(NEW.module_5), '')  IS NOT NULL
       OR NULLIF(trim(NEW.module_6), '')  IS NOT NULL OR NULLIF(trim(NEW.module_7), '')  IS NOT NULL
       OR NULLIF(trim(NEW.module_8), '')  IS NOT NULL OR NULLIF(trim(NEW.module_9), '')  IS NOT NULL
       OR NULLIF(trim(NEW.module_10), '') IS NOT NULL THEN
      RAISE EXCEPTION 'TRADING_PLAN_MODULE_REQUIRES_PREMIUM';
    END IF;
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$function$;

-- Perbaikan yang sama untuk trigger UPDATE-lock supaya konsisten (jaga-jaga
-- kalau modul 4-10 dikirim '' alih-alih NULL saat user Free update baris lama).
CREATE OR REPLACE FUNCTION public.enforce_trading_plan_module_lock()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
declare
  v_is_premium boolean;
begin
  select coalesce(is_premium, false) into v_is_premium
  from public.profiles where id = new.user_id;

  if not v_is_premium then
    if NULLIF(trim(new.module_4), '')  is distinct from NULLIF(trim(old.module_4), '')  or
       NULLIF(trim(new.module_5), '')  is distinct from NULLIF(trim(old.module_5), '')  or
       NULLIF(trim(new.module_6), '')  is distinct from NULLIF(trim(old.module_6), '')  or
       NULLIF(trim(new.module_7), '')  is distinct from NULLIF(trim(old.module_7), '')  or
       NULLIF(trim(new.module_8), '')  is distinct from NULLIF(trim(old.module_8), '')  or
       NULLIF(trim(new.module_9), '')  is distinct from NULLIF(trim(old.module_9), '')  or
       NULLIF(trim(new.module_10), '') is distinct from NULLIF(trim(old.module_10), '') then
      raise exception 'MODUL_TERKUNCI: modul 4-10 hanya untuk Premium';
    end if;
  end if;
  return new;
end;
$function$;
