
revoke execute on function public.trigger_signal_pipeline_mtf(text) from public;
revoke execute on function public.protect_signal_immutable_fields() from public;

grant execute on function public.trigger_signal_pipeline_mtf(text) to service_role, postgres;
grant execute on function public.protect_signal_immutable_fields() to service_role, postgres;
