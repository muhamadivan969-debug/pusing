-- Spec v4.1 section 79: Admin Revision Contract.
-- Admin TIDAK BOLEH mengubah signal immutable secara langsung. Setiap override/revision
-- wajib lewat alur: original signal -> revision request -> reason -> actor -> approval -> new revision -> audit log.
CREATE TABLE IF NOT EXISTS public.signal_revisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_signal_id uuid NOT NULL REFERENCES public.signals(id),
  requested_by uuid NOT NULL REFERENCES public.profiles(id),
  reason text NOT NULL,
  requested_changes jsonb NOT NULL,
  approval_status text NOT NULL DEFAULT 'PENDING' CHECK (approval_status = ANY (ARRAY['PENDING'::text,'APPROVED'::text,'REJECTED'::text])),
  approved_by uuid REFERENCES public.profiles(id),
  approved_at timestamptz,
  new_signal_id uuid REFERENCES public.signals(id),
  audit_id uuid REFERENCES public.audit_logs(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.signal_revisions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "signal_revisions_admin_select" ON public.signal_revisions
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true)
  );

CREATE POLICY "signal_revisions_admin_insert" ON public.signal_revisions
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true)
    AND requested_by = auth.uid()
  );

CREATE POLICY "signal_revisions_service_write" ON public.signal_revisions
  FOR UPDATE USING (auth.role() = 'service_role') WITH CHECK (auth.role() = 'service_role');

-- Snapshot asli signal harus tetap terlihat -- signals TIDAK boleh di-UPDATE langsung oleh admin
-- (worker service_role via edge function tetap boleh untuk lifecycle status). Trigger ini menolak
-- perubahan kolom harga/level immutable dari role selain service_role.
CREATE OR REPLACE FUNCTION public.protect_signal_immutable_fields()
RETURNS trigger AS $$
BEGIN
  IF auth.role() <> 'service_role' THEN
    IF NEW.entry_price IS DISTINCT FROM OLD.entry_price
      OR NEW.buy_area_low IS DISTINCT FROM OLD.buy_area_low
      OR NEW.buy_area_high IS DISTINCT FROM OLD.buy_area_high
      OR NEW.tp1 IS DISTINCT FROM OLD.tp1
      OR NEW.tp2 IS DISTINCT FROM OLD.tp2
      OR NEW.stop_loss IS DISTINCT FROM OLD.stop_loss
      OR NEW.bearish_type IS DISTINCT FROM OLD.bearish_type
      OR NEW.bearish_trigger IS DISTINCT FROM OLD.bearish_trigger
      OR NEW.invalidation IS DISTINCT FROM OLD.invalidation
      OR NEW.downside_support_1 IS DISTINCT FROM OLD.downside_support_1
      OR NEW.downside_support_2 IS DISTINCT FROM OLD.downside_support_2
      OR NEW.evidence IS DISTINCT FROM OLD.evidence
    THEN
      RAISE EXCEPTION 'signal immutable fields tidak boleh diubah langsung -- gunakan alur signal_revisions (spec v4.1 section 79)';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_protect_signal_immutable ON public.signals;
CREATE TRIGGER trg_protect_signal_immutable
  BEFORE UPDATE ON public.signals
  FOR EACH ROW EXECUTE FUNCTION public.protect_signal_immutable_fields();