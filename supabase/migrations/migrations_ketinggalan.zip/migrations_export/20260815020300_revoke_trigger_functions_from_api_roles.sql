-- Fungsi-fungsi ini adalah trigger functions (return type trigger), tidak
-- pernah dimaksudkan dipanggil langsung sebagai RPC dari client. Supabase
-- advisor menandai ini karena PostgREST otomatis expose semua function
-- public sebagai endpoint RPC kecuali di-revoke.

revoke execute on function public.enforce_ai_task_limits() from anon, authenticated, public;
revoke execute on function public.enforce_ai_task_limits_on_update() from anon, authenticated, public;
revoke execute on function public.enforce_trading_plan_module_lock() from anon, authenticated, public;
revoke execute on function public.enforce_trading_plan_module_lock_insert() from anon, authenticated, public;
revoke execute on function public.enforce_watchlist_folder_limit() from anon, authenticated, public;
revoke execute on function public.enforce_watchlist_item_limit() from anon, authenticated, public;
revoke execute on function public.notify_unusual_activity_subscribers() from anon, authenticated, public;
revoke execute on function public.notify_watchlist_new_signal() from anon, authenticated, public;
revoke execute on function public.notify_watchlist_news() from anon, authenticated, public;
revoke execute on function public.protect_sensitive_profile_columns() from anon, authenticated, public;
revoke execute on function public.push_market_cap_to_quote() from anon, authenticated, public;
revoke execute on function public.record_signal_result() from anon, authenticated, public;
revoke execute on function public.sync_quote_market_cap() from anon, authenticated, public;
