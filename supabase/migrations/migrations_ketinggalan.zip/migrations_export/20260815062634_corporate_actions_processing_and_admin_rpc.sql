
ALTER TABLE public.corporate_actions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_corporate_actions" ON public.corporate_actions;
CREATE POLICY "admin_manage_corporate_actions" ON public.corporate_actions
  FOR ALL
  USING (public.is_current_user_admin())
  WITH CHECK (public.is_current_user_admin());

-- RPC: admin mencatat corporate action baru (dipakai dari Admin UI)
CREATE OR REPLACE FUNCTION public.admin_record_corporate_action(
  p_stock_id uuid,
  p_action_type text,
  p_ex_date date,
  p_ratio numeric DEFAULT NULL,
  p_notes text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_id uuid;
BEGIN
  IF NOT public.is_current_user_admin() THEN
    RAISE EXCEPTION 'forbidden: admin only';
  END IF;

  INSERT INTO public.corporate_actions (stock_id, action_type, ex_date, ratio, notes, status)
  VALUES (p_stock_id, p_action_type, p_ex_date, p_ratio, p_notes, 'PENDING')
  RETURNING id INTO v_id;

  INSERT INTO public.audit_logs (actor_id, action, target_table, target_id, detail)
  VALUES (auth.uid(), 'CORPORATE_ACTION_RECORDED', 'corporate_actions', v_id,
    jsonb_build_object('stock_id', p_stock_id, 'action_type', p_action_type, 'ex_date', p_ex_date));

  RETURN v_id;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_record_corporate_action(uuid, text, date, numeric, text) FROM public;
GRANT EXECUTE ON FUNCTION public.admin_record_corporate_action(uuid, text, date, numeric, text) TO authenticated;

-- Pemrosesan: invalidate sinyal ACTIVE/HIT_TP1 pada saham dengan corporate action
-- yang sudah efektif (poin 10.9). DELISTING/SUSPENSION juga menonaktifkan saham.
CREATE OR REPLACE FUNCTION public.process_pending_corporate_actions()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_action record;
  v_processed int := 0;
  v_signals_invalidated int := 0;
  v_count int;
BEGIN
  FOR v_action IN
    SELECT * FROM public.corporate_actions
    WHERE status = 'PENDING'
      AND ex_date <= (now() AT TIME ZONE 'Asia/Jakarta')::date
    ORDER BY ex_date
  LOOP
    UPDATE public.signals
    SET status = 'INVALIDATED', resolved_at = now()
    WHERE stock_id = v_action.stock_id
      AND status IN ('ACTIVE','HIT_TP1')
      AND superseded_by IS NULL;
    GET DIAGNOSTICS v_count = ROW_COUNT;
    v_signals_invalidated := v_signals_invalidated + v_count;

    IF v_action.action_type IN ('DELISTING','SUSPENSION') THEN
      UPDATE public.stocks SET is_active = false WHERE id = v_action.stock_id;
    END IF;

    UPDATE public.corporate_actions
    SET status = 'PROCESSED', processed_at = now()
    WHERE id = v_action.id;

    INSERT INTO public.audit_logs (actor_id, action, target_table, target_id, detail)
    VALUES (NULL, 'CORPORATE_ACTION_PROCESSED', 'corporate_actions', v_action.id,
      jsonb_build_object('stock_id', v_action.stock_id, 'action_type', v_action.action_type, 'signals_invalidated', v_count));

    v_processed := v_processed + 1;
  END LOOP;

  RETURN jsonb_build_object('processed', v_processed, 'signals_invalidated', v_signals_invalidated);
END;
$$;

CREATE OR REPLACE FUNCTION public.trigger_process_corporate_actions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_run_id uuid;
  v_result jsonb;
BEGIN
  v_run_id := public.job_run_start('process-corporate-actions');
  BEGIN
    v_result := public.process_pending_corporate_actions();
    PERFORM public.job_run_finish(v_run_id, 'SUCCESS', v_result);
  EXCEPTION WHEN OTHERS THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('error', SQLERRM));
  END;
END;
$$;

SELECT cron.schedule('process-corporate-actions-daily', '0 22 * * 0-4', $$SELECT public.trigger_process_corporate_actions();$$);
