-- Gabungkan 2 policy SELECT permissive di profiles jadi 1, tanpa ubah perilaku:
-- user tetap bisa lihat profil sendiri, admin tetap bisa lihat semua profil.
DROP POLICY IF EXISTS "own profile" ON public.profiles;
DROP POLICY IF EXISTS admin_select_all_profiles ON public.profiles;

CREATE POLICY profiles_select ON public.profiles
  FOR SELECT
  USING ((SELECT auth.uid()) = id OR public.is_current_user_admin());

CREATE POLICY profiles_insert_own ON public.profiles
  FOR INSERT WITH CHECK ((SELECT auth.uid()) = id);

CREATE POLICY profiles_update_own ON public.profiles
  FOR UPDATE USING ((SELECT auth.uid()) = id);

CREATE POLICY profiles_delete_own ON public.profiles
  FOR DELETE USING ((SELECT auth.uid()) = id);
