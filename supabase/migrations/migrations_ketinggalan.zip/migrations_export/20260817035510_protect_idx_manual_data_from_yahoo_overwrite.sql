-- Spec v4.2 section 3.1-3.2: IDX EOD wajib jadi PRIMARY source, Yahoo cuma emergency
-- fallback. Sebelum ini, fetch-quotes/fetch-candles (Yahoo, jalan tiap 5 menit lewat cron
-- sesi) bisa menimpa data IDX_MANUAL yang sudah diupload admin untuk hari yang sama,
-- karena upsert onConflict-nya tidak sadar soal source/tanggal. Trigger ini mengunci:
-- kalau baris existing sourcenya IDX_MANUAL dan masih untuk hari perdagangan WIB yang sama,
-- upsert dari source lain (YAHOO) di-skip (data lama dipertahankan), bukan ditimpa.

CREATE OR REPLACE FUNCTION protect_idx_manual_quote()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.source = 'IDX_MANUAL'
     AND NEW.source IS DISTINCT FROM 'IDX_MANUAL'
     AND (OLD.market_time AT TIME ZONE 'Asia/Jakarta')::date
       = (COALESCE(NEW.market_time, now()) AT TIME ZONE 'Asia/Jakarta')::date
  THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_idx_manual_quote ON quotes;
CREATE TRIGGER trg_protect_idx_manual_quote
BEFORE UPDATE ON quotes
FOR EACH ROW
EXECUTE FUNCTION protect_idx_manual_quote();

CREATE OR REPLACE FUNCTION protect_idx_manual_candle()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.source = 'IDX_MANUAL' AND NEW.source IS DISTINCT FROM 'IDX_MANUAL' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_idx_manual_candle ON candles;
CREATE TRIGGER trg_protect_idx_manual_candle
BEFORE UPDATE ON candles
FOR EACH ROW
EXECUTE FUNCTION protect_idx_manual_candle();
