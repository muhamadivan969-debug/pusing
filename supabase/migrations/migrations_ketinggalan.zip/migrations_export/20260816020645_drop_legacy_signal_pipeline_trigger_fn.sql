-- trigger_signal_pipeline(timeframe) lama sudah tidak dipanggil cron manapun
-- (diganti trigger_signal_pipeline_mtf(tier)). Drop biar tidak ada kode mati
-- yang manggil generate-signals lama secara manual/tidak sengaja.
drop function if exists public.trigger_signal_pipeline(text);