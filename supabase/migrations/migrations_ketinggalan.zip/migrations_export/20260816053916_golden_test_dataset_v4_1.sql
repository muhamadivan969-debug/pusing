-- Spec v4.1 section 75: Golden Test Dataset -- deterministic regression suite untuk signal engine.
-- Setiap perubahan formula_version wajib menjalankan seluruh golden case ini.
CREATE TABLE IF NOT EXISTS public.golden_test_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_code text NOT NULL UNIQUE CHECK (case_code ~ '^GOLDEN-[0-9]{3}$'),
  category text NOT NULL,
  description text NOT NULL,
  formula_version text NOT NULL DEFAULT 'structural_v1',
  input_snapshot jsonb,
  expected_structure jsonb,
  expected_confluence jsonb,
  expected_signal jsonb,
  expected_levels jsonb,
  expected_lifecycle jsonb,
  expected_evidence jsonb,
  status text NOT NULL DEFAULT 'NOT_POPULATED' CHECK (status = ANY (ARRAY['NOT_POPULATED'::text,'READY'::text,'PASSING'::text,'FAILING'::text])),
  last_run_at timestamptz,
  last_run_result jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.golden_test_cases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "golden_test_cases_admin_select" ON public.golden_test_cases
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true)
  );

CREATE POLICY "golden_test_cases_service_write" ON public.golden_test_cases
  FOR ALL USING (auth.role() = 'service_role') WITH CHECK (auth.role() = 'service_role');

INSERT INTO public.golden_test_cases (case_code, category, description) VALUES
  ('GOLDEN-001', 'Daily BUY', 'Confluence bullish penuh H1->H4->D1, entry & SL dari struktur H1, TP dari resistance D1'),
  ('GOLDEN-002', 'Daily SELL', 'Confluence bearish penuh H1->H4->D1, bearish_type terklasifikasi dari pola candle/volume'),
  ('GOLDEN-003', 'Swing BUY', 'Confluence bullish D1->W1, entry & SL dari struktur D1, TP dari resistance W1'),
  ('GOLDEN-004', 'Swing SELL', 'Confluence bearish D1->W1, downside_support dari struktur W1'),
  ('GOLDEN-005', 'Mixed timeframe', 'Timeframe tidak searah (misal H1 bullish, D1 bearish) -> harus NO SIGNAL, bukan HOLD'),
  ('GOLDEN-006', 'No Signal', 'Semua struktur valid tapi confluence tidak terpenuhi -> tidak ada record signal dibuat'),
  ('GOLDEN-007', 'Overextension', 'Harga sudah jauh dari area entry struktural -> expected NO SIGNAL atau reasoning UI "harga terlalu jauh dari area entry"'),
  ('GOLDEN-008', 'Breakout confirmed', 'Candle close di atas resistance dengan validitas body/wick -> breakout confirmed, bukan intrabar'),
  ('GOLDEN-009', 'Failed breakout', 'Harga sempat breakout intrabar tapi close kembali di bawah resistance -> tidak dianggap breakout confirmed'),
  ('GOLDEN-010', 'Breakdown confirmed', 'Candle close di bawah support dengan validitas body/wick -> bearish_type = BEARISH_BREAKDOWN'),
  ('GOLDEN-011', 'Rejection', 'Harga menembus/menyentuh resistance lalu close di bawah -> bearish_type = BEARISH_REJECTION'),
  ('GOLDEN-012', 'Retest', 'Harga breakout lalu kembali menguji level yang ditembus -> engine membedakan breakout retest vs failed breakout'),
  ('GOLDEN-013', 'Corporate action', 'Saham dengan corporate action pending (split/right issue) -> data candle tidak boleh menghasilkan signal palsu akibat distorsi harga'),
  ('GOLDEN-014', 'Stale data', 'Quotes/candle dengan quality=STALE -> tidak boleh menghasilkan signal baru dari data basi'),
  ('GOLDEN-015', 'Missing data', 'Candle < MIN_CANDLES atau indicator null -> readStructure return null -> skipped, bukan NO SIGNAL/signal palsu'),
  ('GOLDEN-016', 'Same-candle TP/SL ambiguity', 'Dalam satu candle harga menyentuh TP dan SL sekaligus -> evaluate-signals harus punya urutan prioritas deterministic (SL didahulukan sebelum TP, sesuai logic.ts existing)')
ON CONFLICT (case_code) DO NOTHING;

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_golden_test_cases_updated_at ON public.golden_test_cases;
CREATE TRIGGER trg_golden_test_cases_updated_at
  BEFORE UPDATE ON public.golden_test_cases
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();