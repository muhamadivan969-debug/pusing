create unique index token_transactions_type_reference_id_uniq
on public.token_transactions (type, reference_id)
where reference_id is not null;