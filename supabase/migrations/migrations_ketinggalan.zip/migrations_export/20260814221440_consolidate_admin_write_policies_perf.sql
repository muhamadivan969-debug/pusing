-- Perf linter: "multiple permissive policies" untuk SELECT di corporate_actions,
-- earnings_calendar, ipo_calendar karena policy admin "ALL" (mencakup SELECT juga)
-- tumpang tindih dengan policy "readable by all" (SELECT). Perilaku akses TIDAK
-- berubah (admin dan public tetap bisa SELECT), cuma dipersempit supaya policy
-- admin tidak lagi dobel-evaluasi SELECT.

DROP POLICY IF EXISTS corporate_actions_admin_write ON public.corporate_actions;
CREATE POLICY corporate_actions_admin_insert ON public.corporate_actions
  FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = (SELECT auth.uid()) AND profiles.is_admin = true));
CREATE POLICY corporate_actions_admin_update ON public.corporate_actions
  FOR UPDATE USING (EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = (SELECT auth.uid()) AND profiles.is_admin = true));
CREATE POLICY corporate_actions_admin_delete ON public.corporate_actions
  FOR DELETE USING (EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = (SELECT auth.uid()) AND profiles.is_admin = true));

DROP POLICY IF EXISTS admin_write_earnings_calendar ON public.earnings_calendar;
CREATE POLICY admin_insert_earnings_calendar ON public.earnings_calendar
  FOR INSERT WITH CHECK (public.is_current_user_admin());
CREATE POLICY admin_update_earnings_calendar ON public.earnings_calendar
  FOR UPDATE USING (public.is_current_user_admin());
CREATE POLICY admin_delete_earnings_calendar ON public.earnings_calendar
  FOR DELETE USING (public.is_current_user_admin());

DROP POLICY IF EXISTS admin_write_ipo_calendar ON public.ipo_calendar;
CREATE POLICY admin_insert_ipo_calendar ON public.ipo_calendar
  FOR INSERT WITH CHECK (public.is_current_user_admin());
CREATE POLICY admin_update_ipo_calendar ON public.ipo_calendar
  FOR UPDATE USING (public.is_current_user_admin());
CREATE POLICY admin_delete_ipo_calendar ON public.ipo_calendar
  FOR DELETE USING (public.is_current_user_admin());
