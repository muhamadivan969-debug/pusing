
-- Ternyata revoke EXECUTE ... FROM anon saja tidak cukup: PostgreSQL otomatis GRANT EXECUTE
-- ke pseudo-role PUBLIC saat function dibuat, dan anon/authenticated adalah member PUBLIC,
-- jadi grant PUBLIC itu tetap berlaku walau sudah di-revoke dari anon/authenticated secara
-- eksplisit. Harus revoke dari PUBLIC juga, baru re-grant secara selektif ke role yang benar.

revoke execute on function public.admin_dashboard_summary() from public;
revoke execute on function public.admin_invalidate_signal(uuid, text) from public;
revoke execute on function public.is_current_user_admin() from public;
revoke execute on function public.trigger_fetch_news() from public;
revoke execute on function public.trigger_master_sync_stock() from public;
revoke execute on function public.trigger_fetch_earnings_calendar() from public;
revoke execute on function public.trigger_fetch_fundamentals() from public;
revoke execute on function public.trigger_generate_trending_reason() from public;
revoke execute on function public.trigger_detect_unusual_activity() from public;
revoke execute on function public.trigger_morning_briefing() from public;
revoke execute on function public.trigger_trending_score() from public;
revoke execute on function public.trigger_ai_task_executor() from public;
revoke execute on function public.trigger_unusual_activity_detection() from public;
revoke execute on function public.reconcile_job_runs() from public;
revoke execute on function public.trigger_signal_pipeline(text) from public;
revoke execute on function public.trigger_fetch_index() from public;
revoke execute on function public.trigger_fetch_quotes() from public;
revoke execute on function public.trigger_fetch_economic_calendar() from public;
revoke execute on function public.expire_grace_subscriptions() from public;
revoke execute on function public.process_corporate_actions() from public;
revoke execute on function public.trigger_fetch_ipo_calendar() from public;
revoke execute on function public.compute_sector_rotation() from public;
revoke execute on function public.trigger_evaluate_signals() from public;

-- Re-grant EXECUTE hanya ke authenticated untuk fungsi yang memang perlu dipanggil
-- user login (fungsi ini sudah punya pengecekan is_admin di dalamnya sendiri).
grant execute on function public.admin_dashboard_summary() to authenticated;
grant execute on function public.admin_invalidate_signal(uuid, text) to authenticated;
grant execute on function public.is_current_user_admin() to authenticated;

-- Fungsi trigger_*/reconcile_*/process_*/compute_*/expire_* murni internal worker (dipanggil
-- pg_cron sebagai superuser/postgres, yang tidak butuh grant eksplisit). Tidak di-re-grant
-- ke anon maupun authenticated sama sekali.
