
-- Sesuai spek produk 5.7: maksimal 10 folder watchlist per user, maksimal 50 saham per folder.
-- Sebelumnya tidak di-enforce sama sekali di DB (cuma asumsi dicek di frontend).
CREATE OR REPLACE FUNCTION public.enforce_watchlist_folder_limit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer;
BEGIN
  SELECT count(*) INTO v_count FROM public.watchlists WHERE user_id = NEW.user_id;
  IF v_count >= 10 THEN
    RAISE EXCEPTION 'WATCHLIST_FOLDER_LIMIT: maksimal 10 folder watchlist per user';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_watchlist_folder_limit ON public.watchlists;
CREATE TRIGGER trg_enforce_watchlist_folder_limit
  BEFORE INSERT ON public.watchlists
  FOR EACH ROW EXECUTE FUNCTION public.enforce_watchlist_folder_limit();

CREATE OR REPLACE FUNCTION public.enforce_watchlist_item_limit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer;
BEGIN
  SELECT count(*) INTO v_count FROM public.watchlist_items WHERE watchlist_id = NEW.watchlist_id;
  IF v_count >= 50 THEN
    RAISE EXCEPTION 'WATCHLIST_ITEM_LIMIT: maksimal 50 saham per folder watchlist';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_watchlist_item_limit ON public.watchlist_items;
CREATE TRIGGER trg_enforce_watchlist_item_limit
  BEFORE INSERT ON public.watchlist_items
  FOR EACH ROW EXECUTE FUNCTION public.enforce_watchlist_item_limit();
