-- FIX KRITIS: fungsi worker/cron ini SECURITY DEFINER tanpa cek otorisasi
-- di dalamnya, dan ter-expose ke role anon & authenticated lewat PostgREST
-- RPC (/rest/v1/rpc/<nama_fungsi>). Siapa pun tanpa login bisa memicu job
-- ini berkali-kali (boros biaya OpenRouter/Edge Function, spam job_runs,
-- race condition data). Fungsi-fungsi ini seharusnya HANYA dipanggil oleh
-- pg_cron (internal, bukan lewat REST) sehingga aman untuk cabut akses
-- publiknya tanpa mengganggu jadwal cron yang sudah ada.

REVOKE EXECUTE ON FUNCTION public.trigger_fetch_news() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_master_sync_stock() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_fetch_ipo_calendar() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_fetch_earnings_calendar() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_fetch_fundamentals() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_generate_trending_reason() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_detect_unusual_activity() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_morning_briefing() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.compute_sector_rotation() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.sync_stock_master() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.process_corporate_actions() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.dispatch_morning_briefing() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.expire_grace_subscriptions() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.reconcile_fetch_ipo_calendar() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_fetch_quotes() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_evaluate_signals() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_ai_task_executor() FROM PUBLIC, anon, authenticated;
