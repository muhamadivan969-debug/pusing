-- sector_rotation_scores dipakai SectorRotationFlow.tsx via .from() langsung
-- (bukan RPC), tapi anon belum pernah dikasih GRANT SELECT — konsisten dengan
-- data pasar publik lain (stocks, quotes, sectors, dll yang sudah terbuka).
-- Data ini tidak sensitif (skor rotasi sektor agregat, bukan data per-user).

grant select on public.sector_rotation_scores to anon, authenticated;

drop policy if exists "public read of sector rotation scores" on public.sector_rotation_scores;
create policy "public read of sector rotation scores"
  on public.sector_rotation_scores
  for select
  to anon, authenticated
  using (true);
