DROP POLICY IF EXISTS "admin manage idx_eod_uploads" ON public.idx_eod_uploads;

CREATE POLICY "admin manage idx_eod_uploads" ON public.idx_eod_uploads
  FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true));