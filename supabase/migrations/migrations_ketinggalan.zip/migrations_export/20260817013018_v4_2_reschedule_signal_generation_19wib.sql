-- Spec v4.2 section 4.1: generate sinyal utama jam 19.00 WIB (bukan 16.30 WIB / 09:30 UTC)
-- 19:00 WIB = 12:00 UTC
SELECT cron.alter_job(
  (SELECT jobid FROM cron.job WHERE jobname = 'signal-pipeline-mtf-daily'),
  schedule := '0 12 * * 1-5'
);
SELECT cron.alter_job(
  (SELECT jobid FROM cron.job WHERE jobname = 'signal-pipeline-mtf-swing'),
  schedule := '0 12 * * 1-5'
);
