-- Trigger sebelumnya akan memblokir request_account_deletion() karena auth.role() tetap 'authenticated'
-- meskipun function-nya SECURITY DEFINER. Tambahkan jalur trusted via session flag lokal
-- yang cuma di-set oleh RPC tepercaya (bukan bisa di-set sembarangan oleh client karena
-- 'set local' hanya berlaku dalam transaksi RPC itu sendiri, dan client tidak punya cara
-- mengeset GUC session dari REST API biasa).

create or replace function public.protect_sensitive_profile_columns()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $$
begin
  if auth.role() <> 'service_role'
     and coalesce(current_setting('app.trusted_profile_update', true), '') <> 'on' then
    new.is_premium := old.is_premium;
    new.is_admin := old.is_admin;
    new.is_active := old.is_active;
    new.deleted_at := old.deleted_at;
  end if;
  return new;
end;
$$;

create or replace function public.request_account_deletion(p_reason text default null)
returns void
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then
    raise exception 'Not authenticated';
  end if;

  perform set_config('app.trusted_profile_update', 'on', true);

  update public.profiles
  set deleted_at = now(), is_active = false
  where id = v_uid and deleted_at is null;

  update public.subscriptions
  set cancel_at_period_end = true
  where user_id = v_uid and status = 'active';

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, detail)
  values (v_uid, 'ACCOUNT_DELETE_REQUESTED', 'profiles', v_uid, jsonb_build_object('reason', p_reason));
end;
$function$;
