
drop policy if exists "backtest_runs readable by all" on public.backtest_runs;

create policy "backtest_runs readable by admin only"
on public.backtest_runs
for select
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.is_admin = true
  )
);
