-- Jadwal lama salah: 15:25 WIB dianggap "closing" padahal Sesi 2 BEI baru berakhir 15:49 WIB
-- dan closing price resmi baru settle ~16:00-16:15 WIB (pre-closing 15:50-16:00, post-closing 16:00-16:15).
-- fetch-quotes-close/fetch-index-close sudah benar di 16:17 WIB (09:17 UTC).
-- Geser signal-pipeline-mtf closing ke 16:30 WIB (09:30 UTC) supaya pakai data setelah closing resmi + buffer.
-- Swing diubah dari Jumat-saja jadi tiap hari trading, karena expire-nya cuma 1 hari (poin 6.9 dokumen).

SELECT cron.alter_job(
  job_id := 65,
  schedule := '30 9 * * 1-5'  -- 16:30 WIB, Senin-Jumat (Daily closing utama)
);

SELECT cron.alter_job(
  job_id := 66,
  schedule := '30 9 * * 1-5'  -- 16:30 WIB, Senin-Jumat (Swing, sebelumnya Jumat-only)
);

-- Trigger baru: Daily intraday re-eval jam 12:10 WIB (05:10 UTC), Senin-Jumat, sesuai dokumen 9.3
SELECT cron.schedule(
  'signal-pipeline-mtf-daily-intraday',
  '10 5 * * 1-5',
  $$select public.trigger_signal_pipeline_mtf('daily');$$
);
