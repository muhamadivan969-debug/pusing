
-- FREN (Smartfren) delisting 17 Apr 2025 - merger ke EXCL/XLSmart
-- MASA (Multistrada) delisting 2025 - go-private
-- MFIN (Mandala Multifinance) delisting 2 Okt 2025 - merger ke ADMF
-- Ketiganya sudah tidak ada di Yahoo Finance (404 "may be delisted") tapi is_active masih true,
-- jadi worker fetch-quotes terus-terusan gagal mencoba fetch data yang memang sudah tidak ada.

with target as (
  select id, ticker from public.stocks where ticker in ('FREN','MASA','MFIN')
)
insert into public.corporate_actions (stock_id, action_type, ex_date, status, notes)
select id, 'DELISTING', case ticker
    when 'FREN' then '2025-04-17'::date
    when 'MASA' then '2025-10-01'::date
    when 'MFIN' then '2025-10-02'::date
  end,
  'PROCESSED',
  case ticker
    when 'FREN' then 'Merger ke PT XLSmart Telecom Sejahtera Tbk (EXCL), delisting resmi 17 April 2025'
    when 'MASA' then 'Voluntary delisting / go-private (Grup Michelin)'
    when 'MFIN' then 'Merger ke PT Adira Dinamika Multi Finance Tbk (ADMF), delisting resmi 2 Oktober 2025'
  end
from target;

update public.stocks
set is_active = false
where ticker in ('FREN','MASA','MFIN');

insert into public.audit_logs (actor_id, action, entity_type, entity_id, detail)
select null, 'AUDIT_MARK_DELISTED', 'stock', id,
  jsonb_build_object('ticker', ticker, 'reason', 'Konfirmasi delisting BEI via web search, Yahoo Finance 404 not found')
from public.stocks where ticker in ('FREN','MASA','MFIN');
