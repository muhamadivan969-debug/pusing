-- 5 fungsi ini ketemu lagi bisa dipanggil publik (anon/authenticated) padahal
-- seharusnya cuma dipanggil internal (cron/trigger), bukan end-user via REST API.
-- Kemungkinan ke-grant ulang oleh migration setelahnya. Revoke permanen di sini.
REVOKE EXECUTE ON FUNCTION public.process_pending_corporate_actions() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.rls_auto_enable() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_generate_signal_reasoning() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_process_corporate_actions() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.notify_push_on_new_notification() FROM anon, authenticated;