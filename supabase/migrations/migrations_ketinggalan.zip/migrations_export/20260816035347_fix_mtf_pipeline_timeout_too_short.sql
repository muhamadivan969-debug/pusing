CREATE OR REPLACE FUNCTION public.trigger_signal_pipeline_mtf(p_tier text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_url text;
  v_key text;
  v_secret text;
  v_headers jsonb;
  v_run_id uuid;
  v_req bigint;
  v_res jsonb;
  v_timeframes text[];
  v_tf text;
BEGIN
  v_run_id := public.job_run_start('signal-pipeline-mtf-' || p_tier);

  IF p_tier = 'daily' THEN
    v_timeframes := ARRAY['H1','H4','D1'];
  ELSIF p_tier = 'swing' THEN
    v_timeframes := ARRAY['D1','W1'];
  ELSE
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'tier tidak dikenal: ' || p_tier));
    RETURN;
  END IF;

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';

  IF v_url IS NULL OR v_key IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'vault secrets belum diset'));
    RETURN;
  END IF;

  v_headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret);

  -- Tahap 1-2 per timeframe yang dibutuhkan tier ini: fetch-candles lalu compute-indicators
  -- NOTE: fetch-candles utk ~950 saham butuh ~120-130s riil (diukur 16 Agt 2026), jadi
  -- timeout pg_net & wait dinaikkan dari 120000ms/110s -> 240000ms/220s supaya ada margin aman.
  FOREACH v_tf IN ARRAY v_timeframes LOOP
    SELECT net.http_post(url := v_url || '/functions/v1/fetch-candles?timeframe=' || v_tf, headers := v_headers, timeout_milliseconds := 240000) INTO v_req;
    v_res := public.wait_for_net_response(v_req, 220);
    IF NOT (v_res->>'ok')::boolean THEN
      PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'fetch-candles', 'timeframe', v_tf, 'result', v_res));
      RETURN;
    END IF;

    SELECT net.http_post(url := v_url || '/functions/v1/compute-indicators?timeframe=' || v_tf, headers := v_headers, timeout_milliseconds := 240000) INTO v_req;
    v_res := public.wait_for_net_response(v_req, 220);
    IF NOT (v_res->>'ok')::boolean THEN
      PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'compute-indicators', 'timeframe', v_tf, 'result', v_res));
      RETURN;
    END IF;
  END LOOP;

  -- Tahap 3: generate-signals-mtf, sekali untuk seluruh tier (bukan per timeframe)
  SELECT net.http_post(url := v_url || '/functions/v1/generate-signals-mtf?tier=' || p_tier, headers := v_headers, timeout_milliseconds := 240000) INTO v_req;
  v_res := public.wait_for_net_response(v_req, 220);
  IF NOT (v_res->>'ok')::boolean THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'generate-signals-mtf', 'result', v_res));
    RETURN;
  END IF;

  PERFORM public.job_run_finish(v_run_id, 'SUCCESS', jsonb_build_object(
    'note', 'fetch-candles+compute-indicators (' || array_to_string(v_timeframes, ',') || ') -> generate-signals-mtf selesai',
    'tier', p_tier,
    'generate_signals_mtf_result', v_res
  ));
END;
$function$;
