CREATE OR REPLACE FUNCTION public.credit_ad_unlock_verified(
  p_user_id uuid,
  p_stock_id uuid,
  p_transaction_id text,
  p_reward_item text DEFAULT NULL,
  p_reward_amount numeric DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
declare
  v_wallet public.token_wallets;
  v_today date := (now() at time zone 'Asia/Jakarta')::date;
begin
  -- Idempotency: transaction_id dari AdMob cuma boleh diproses sekali
  begin
    insert into public.ad_verifications (transaction_id, user_id, stock_id, reward_item, reward_amount)
    values (p_transaction_id, p_user_id, p_stock_id, p_reward_item, p_reward_amount);
  exception when unique_violation then
    return jsonb_build_object('status', 'ok', 'already_processed', true);
  end;

  v_wallet := public.ensure_wallet_current(p_user_id);

  if exists (
    select 1 from public.signal_unlocks
    where user_id = p_user_id and stock_id = p_stock_id and unlock_date = v_today
  ) then
    return jsonb_build_object('status', 'ok', 'already_unlocked', true);
  end if;

  -- FIX: enforce batas 3 iklan/hari (spec 7.1) -- sebelumnya tidak dicek di sini,
  -- cuma dicek di jalur placeholder unlock_signal_with_ad.
  if v_wallet.ad_unlock_count >= 3 then
    return jsonb_build_object('status', 'error', 'reason', 'AD_LIMIT_REACHED');
  end if;

  update public.token_wallets
    set ad_unlock_count = ad_unlock_count + 1
    where id = v_wallet.id;

  insert into public.token_transactions (wallet_id, amount, type, reference_id)
  values (v_wallet.id, 0, 'AD_UNLOCK', p_stock_id);

  insert into public.signal_unlocks (user_id, stock_id, unlock_date, source)
  values (p_user_id, p_stock_id, v_today, 'AD')
  on conflict (user_id, stock_id, unlock_date) do nothing;

  return jsonb_build_object('status', 'ok', 'ad_unlock_count', v_wallet.ad_unlock_count + 1);
end;
$$;