
-- Index untuk query list_active_signals yang paling sering dijalankan
CREATE INDEX IF NOT EXISTS idx_signals_active_gate
ON public.signals (status, gate_passed, superseded_by, created_at DESC)
WHERE gate_passed = true AND superseded_by IS NULL;

-- Index untuk get_signal_for_stock (query per saham)
CREATE INDEX IF NOT EXISTS idx_signals_stock_active_gate
ON public.signals (stock_id, status, gate_passed, superseded_by, created_at DESC)
WHERE gate_passed = true AND superseded_by IS NULL;

-- Index untuk signal_unlocks - query paling sering di unlock check
CREATE INDEX IF NOT EXISTS idx_signal_unlocks_user_date
ON public.signal_unlocks (user_id, unlock_date);
