
-- Helper: tunggu response pg_net sampai selesai (atau timeout), alih-alih fire-and-forget.
CREATE OR REPLACE FUNCTION public.wait_for_net_response(p_request_id bigint, p_max_wait_seconds integer DEFAULT 100)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_row net._http_response%ROWTYPE;
  v_waited integer := 0;
BEGIN
  LOOP
    SELECT * INTO v_row FROM net._http_response WHERE id = p_request_id;
    IF FOUND THEN
      IF v_row.error_msg IS NOT NULL THEN
        RETURN jsonb_build_object('ok', false, 'status_code', v_row.status_code, 'error_msg', v_row.error_msg);
      ELSIF v_row.status_code IS NOT NULL AND v_row.status_code >= 200 AND v_row.status_code < 300 THEN
        RETURN jsonb_build_object('ok', true, 'status_code', v_row.status_code, 'content', left(v_row.content, 2000));
      ELSE
        RETURN jsonb_build_object('ok', false, 'status_code', v_row.status_code, 'content', left(v_row.content, 2000));
      END IF;
    END IF;
    IF v_waited >= p_max_wait_seconds THEN
      RETURN jsonb_build_object('ok', false, 'error_msg', 'timeout menunggu net response setelah ' || p_max_wait_seconds || 's', 'timed_out', true);
    END IF;
    PERFORM pg_sleep(1);
    v_waited := v_waited + 1;
  END LOOP;
END;
$$;

-- Rewrite trigger_signal_pipeline: sekarang berurutan BENAR-BENAR menunggu tiap
-- tahap selesai (fetch-candles -> compute-indicators -> generate-signals)
-- sebelum lanjut ke tahap berikutnya. Kalau satu tahap gagal/timeout, tahap
-- berikutnya TIDAK dipanggil (mencegah generate-signals jalan dengan candle/
-- indikator yang belum ter-update -- race condition sebelumnya).
CREATE OR REPLACE FUNCTION public.trigger_signal_pipeline(p_timeframe text)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  v_url text;
  v_key text;
  v_secret text;
  v_headers jsonb;
  v_run_id uuid;
  v_req bigint;
  v_res jsonb;
BEGIN
  v_run_id := public.job_run_start('signal-pipeline-' || p_timeframe);

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';

  IF v_url IS NULL OR v_key IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'vault secrets belum diset'));
    RETURN;
  END IF;

  v_headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret);

  -- Tahap 1: fetch-candles
  SELECT net.http_post(url := v_url || '/functions/v1/fetch-candles?timeframe=' || p_timeframe, headers := v_headers, timeout_milliseconds := 120000) INTO v_req;
  v_res := public.wait_for_net_response(v_req, 110);
  IF NOT (v_res->>'ok')::boolean THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'fetch-candles', 'result', v_res));
    RETURN;
  END IF;

  -- Tahap 2: compute-indicators (baru jalan setelah candle SELESAI ter-update)
  SELECT net.http_post(url := v_url || '/functions/v1/compute-indicators?timeframe=' || p_timeframe, headers := v_headers, timeout_milliseconds := 120000) INTO v_req;
  v_res := public.wait_for_net_response(v_req, 110);
  IF NOT (v_res->>'ok')::boolean THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'compute-indicators', 'result', v_res));
    RETURN;
  END IF;

  -- Tahap 3: generate-signals (baru jalan setelah indikator SELESAI ter-update)
  SELECT net.http_post(url := v_url || '/functions/v1/generate-signals?timeframe=' || p_timeframe, headers := v_headers, timeout_milliseconds := 120000) INTO v_req;
  v_res := public.wait_for_net_response(v_req, 110);
  IF NOT (v_res->>'ok')::boolean THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'generate-signals', 'result', v_res));
    RETURN;
  END IF;

  PERFORM public.job_run_finish(v_run_id, 'SUCCESS', jsonb_build_object(
    'note', 'fetch-candles -> compute-indicators -> generate-signals selesai berurutan (sinkron)',
    'generate_signals_result', v_res
  ));
END;
$$;
