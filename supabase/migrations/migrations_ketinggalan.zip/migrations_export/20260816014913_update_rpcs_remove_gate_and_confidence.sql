
create or replace function public.get_signal_for_stock(p_stock_id uuid, p_tier text default 'daily')
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_user       uuid := auth.uid();
  v_today      date := (now() at time zone 'Asia/Jakarta')::date;
  v_signal     public.signals;
  v_is_premium boolean := false;
  v_unlocked   boolean := false;
  v_result     jsonb;
begin
  select * into v_signal from public.signals
    where stock_id = p_stock_id and status = 'ACTIVE' and superseded_by is null
      and signal_tier = p_tier
    order by created_at desc
    limit 1;

  if not found then
    return null;
  end if;

  if v_user is not null then
    select coalesce(is_premium, false) into v_is_premium from public.profiles where id = v_user;
    v_unlocked := v_is_premium or exists (
      select 1 from public.signal_unlocks
      where user_id = v_user and stock_id = p_stock_id and unlock_date = v_today
    );
  end if;

  v_result := jsonb_build_object(
    'id', v_signal.id,
    'direction', v_signal.direction,
    'status', v_signal.status,
    'signal_tier', v_signal.signal_tier,
    'created_at', v_signal.created_at,
    'unlocked', v_unlocked
  );

  if v_unlocked then
    v_result := v_result || jsonb_build_object(
      'entry_price', v_signal.entry_price,
      'buy_area_low', v_signal.buy_area_low,
      'buy_area_high', v_signal.buy_area_high,
      'support_level', v_signal.support_level,
      'resistance_level', v_signal.resistance_level,
      'tp1', v_signal.tp1,
      'tp2', v_signal.tp2,
      'stop_loss', v_signal.stop_loss,
      'ai_reasoning', v_signal.ai_reasoning
    );
  end if;

  return v_result;
end;
$function$;

create or replace function public.list_active_signals(p_tier text default null)
returns table(id uuid, direction text, status text, signal_tier text, created_at timestamp with time zone, stock_id uuid, ticker text, name text, entry_price numeric, buy_area_low numeric, buy_area_high numeric, support_level numeric, resistance_level numeric, tp1 numeric, tp2 numeric, stop_loss numeric, current_price numeric, unlocked boolean)
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_user uuid := auth.uid();
  v_today date := (now() at time zone 'Asia/Jakarta')::date;
  v_is_premium boolean := false;
begin
  if v_user is not null then
    select coalesce(p.is_premium, false) into v_is_premium
    from public.profiles p where p.id = v_user;
  end if;

  return query
  select
    s.id, s.direction, s.status, s.signal_tier, s.created_at,
    st.id as stock_id, st.ticker, st.name,
    case when (v_is_premium or exists (
      select 1 from public.signal_unlocks su
      where su.user_id = v_user and su.stock_id = st.id and su.unlock_date = v_today
    )) then s.entry_price else null end,
    case when (v_is_premium or exists (
      select 1 from public.signal_unlocks su
      where su.user_id = v_user and su.stock_id = st.id and su.unlock_date = v_today
    )) then s.buy_area_low else null end,
    case when (v_is_premium or exists (
      select 1 from public.signal_unlocks su
      where su.user_id = v_user and su.stock_id = st.id and su.unlock_date = v_today
    )) then s.buy_area_high else null end,
    s.support_level,
    s.resistance_level,
    case when (v_is_premium or exists (
      select 1 from public.signal_unlocks su
      where su.user_id = v_user and su.stock_id = st.id and su.unlock_date = v_today
    )) then s.tp1 else null end,
    case when (v_is_premium or exists (
      select 1 from public.signal_unlocks su
      where su.user_id = v_user and su.stock_id = st.id and su.unlock_date = v_today
    )) then s.tp2 else null end,
    case when (v_is_premium or exists (
      select 1 from public.signal_unlocks su
      where su.user_id = v_user and su.stock_id = st.id and su.unlock_date = v_today
    )) then s.stop_loss else null end,
    q.price as current_price,
    (v_is_premium or exists (
      select 1 from public.signal_unlocks su
      where su.user_id = v_user and su.stock_id = st.id and su.unlock_date = v_today
    )) as unlocked
  from public.signals s
  join public.stocks st on st.id = s.stock_id
  left join public.quotes q on q.stock_id = st.id
  where s.status in ('ACTIVE', 'HIT_TP1')
    and s.superseded_by is null
    and (p_tier is null or s.signal_tier = p_tier)
  order by s.created_at desc;
end;
$function$;

create or replace function public.get_signal_history(p_status text default null, p_days integer default null, p_limit integer default 50, p_offset integer default 0)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_user uuid := auth.uid();
  v_is_premium boolean := false;
  v_result jsonb;
begin
  if v_user is not null then
    select coalesce(is_premium, false) into v_is_premium from public.profiles where id = v_user;
  end if;

  select jsonb_agg(row_to_json(t)) into v_result from (
    select
      sg.id, st.ticker, st.name as stock_name, sg.direction, sg.timeframe, sg.signal_tier,
      sg.status, sg.created_at, sg.resolved_at, sr.result, sr.r_multiple,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then true else false end as unlocked,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.entry_price else null end as entry_price,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.tp1 else null end as tp1,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.tp2 else null end as tp2,
      case when v_is_premium or (v_user is not null and exists (
        select 1 from public.signal_unlocks su
        where su.user_id = v_user and su.stock_id = sg.stock_id
          and su.unlock_date = (sg.created_at at time zone 'Asia/Jakarta')::date
      )) then sg.stop_loss else null end as stop_loss
    from public.signals sg
    join public.stocks st on st.id = sg.stock_id
    left join public.signal_results sr on sr.signal_id = sg.id
    where sg.status in ('HIT_TP1','HIT_TP2','HIT_SL','EXPIRED','INVALIDATED')
      and (p_status is null or sg.status = p_status)
      and (p_days is null or sg.created_at >= now() - (p_days || ' days')::interval)
    order by sg.created_at desc
    limit p_limit offset p_offset
  ) t;

  return coalesce(v_result, '[]'::jsonb);
end;
$function$;
