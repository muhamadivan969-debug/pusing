
create policy "structure_zones readable by all"
on public.structure_zones for select to public using (true);

create policy "structure_labels readable by all"
on public.structure_labels for select to public using (true);
