-- FIX: notifications.category pakai UPPERCASE (MARKET/SIGNAL/NEWS/ECONOMIC_EVENT/
-- MORNING_BRIEFING/UNUSUAL_ACTIVITY per check constraint), tapi trigger yang baru
-- dibuat tadi salah bandingin ke lowercase -- jadi push notification gak pernah
-- ke-trigger walau user sudah subscribe & preference-nya ON. Diperbaiki di sini.

CREATE OR REPLACE FUNCTION public.notify_push_on_new_notification()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
DECLARE
  v_pref record;
  v_allowed boolean := true;
  v_url text; v_key text; v_secret text; v_req_id bigint;
BEGIN
  SELECT * INTO v_pref FROM public.notification_preferences WHERE user_id = NEW.user_id;

  IF v_pref IS NOT NULL THEN
    IF v_pref.master_enabled = false THEN
      v_allowed := false;
    ELSIF NEW.category = 'MARKET' AND v_pref.market_alerts = false THEN v_allowed := false;
    ELSIF NEW.category = 'SIGNAL' AND v_pref.signal_alerts = false THEN v_allowed := false;
    ELSIF NEW.category = 'NEWS' AND v_pref.news_updates = false THEN v_allowed := false;
    ELSIF NEW.category = 'ECONOMIC_EVENT' AND v_pref.economic_events = false THEN v_allowed := false;
    ELSIF NEW.category = 'MORNING_BRIEFING' AND v_pref.morning_briefing = false THEN v_allowed := false;
    ELSIF NEW.category = 'UNUSUAL_ACTIVITY' AND v_pref.unusual_activity_alert = false THEN v_allowed := false;
    END IF;
  END IF;

  IF NOT v_allowed THEN
    RETURN NEW;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.push_subscriptions WHERE user_id = NEW.user_id) THEN
    RETURN NEW;
  END IF;

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT net.http_post(
    url := v_url || '/functions/v1/send-web-push',
    headers := jsonb_build_object('Authorization','Bearer ' || v_key,'Content-Type','application/json','x-worker-secret', v_secret),
    body := jsonb_build_object(
      'user_id', NEW.user_id,
      'title', NEW.title,
      'body', NEW.body,
      'category', NEW.category,
      'reference_id', NEW.reference_id
    ),
    timeout_milliseconds := 15000
  ) INTO v_req_id;

  RETURN NEW;
END;
$function$;
