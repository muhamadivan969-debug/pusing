
alter table public.unusual_activities
  add column if not exists baseline numeric,
  add column if not exists threshold numeric,
  add column if not exists formula text,
  add column if not exists window_label text,
  add column if not exists data_source text default 'yahoo_finance';

update public.unusual_activities
set baseline = avg_volume_20d
where baseline is null;
