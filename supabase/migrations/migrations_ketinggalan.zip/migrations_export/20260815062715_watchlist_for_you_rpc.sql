
-- RPC "For You" (poin 5.7): rekomendasi saham berdasarkan Risk Profile user.
-- Konservatif -> big cap (>10T), Moderat -> mid cap (2-10T), Agresif -> small cap (<2T).
-- Hanya kembalikan data yang memang free (ticker, nama, harga, arah sinyal) - tidak bocorkan detail terkunci.
CREATE OR REPLACE FUNCTION public.get_for_you_stocks(p_limit int DEFAULT 10)
RETURNS TABLE (
  stock_id uuid,
  ticker text,
  name text,
  price numeric,
  change_percent numeric,
  signal_direction text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_risk_profile text;
  v_cap_min numeric;
  v_cap_max numeric;
BEGIN
  SELECT risk_profile INTO v_risk_profile FROM public.profiles WHERE id = auth.uid();

  IF v_risk_profile = 'KONSERVATIF' THEN
    v_cap_min := 10000000000000; v_cap_max := NULL;
  ELSIF v_risk_profile = 'MODERAT' THEN
    v_cap_min := 2000000000000; v_cap_max := 10000000000000;
  ELSE
    v_cap_min := 0; v_cap_max := 2000000000000;
  END IF;

  RETURN QUERY
  SELECT s.id, s.ticker, s.name, q.price,
    round(((q.price - q.previous_close) / NULLIF(q.previous_close, 0)) * 100, 2) AS change_percent,
    sig.direction
  FROM public.stocks s
  JOIN public.quotes q ON q.stock_id = s.id
  LEFT JOIN LATERAL (
    SELECT direction FROM public.signals
    WHERE stock_id = s.id AND status IN ('ACTIVE','HIT_TP1') AND superseded_by IS NULL
    ORDER BY created_at DESC LIMIT 1
  ) sig ON true
  WHERE s.is_active = true
    AND q.market_cap >= v_cap_min
    AND (v_cap_max IS NULL OR q.market_cap < v_cap_max)
  ORDER BY (sig.direction = 'BUY') DESC NULLS LAST, q.market_cap DESC
  LIMIT p_limit;
END;
$$;

REVOKE ALL ON FUNCTION public.get_for_you_stocks(int) FROM public;
GRANT EXECUTE ON FUNCTION public.get_for_you_stocks(int) TO authenticated;
