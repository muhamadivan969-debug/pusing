
-- REDESIGN: statement_timeout 2 menit dipaksain di level platform Supabase, tidak bisa
-- di-override lewat ALTER FUNCTION ... SET statement_timeout (sudah dites & terbukti gagal).
-- Pola lama (satu function nunggu net response pakai loop pg_sleep) TIDAK PERNAH bisa
-- selesai untuk proses full 948 saham (~130s+ per stage). Ganti jadi state machine async:
-- trigger_signal_pipeline_mtf() cuma nembak request pertama lalu return cepat (tidak nunggu).
-- mtf_pipeline_poll() dijalankan cron tiap 1 menit, cek response yg sudah selesai, lanjut
-- ke stage berikutnya. Tidak ada satupun statement yang nunggu lama -> aman dari timeout.

CREATE TABLE IF NOT EXISTS public.mtf_pipeline_runs (
  id uuid primary key default gen_random_uuid(),
  tier text not null,
  status text not null default 'RUNNING',
  stage text not null,
  timeframes text[] not null,
  tf_index int not null default 1,
  pending_request_id bigint not null,
  job_run_id uuid not null,
  detail jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
CREATE INDEX IF NOT EXISTS idx_mtf_pipeline_runs_status ON public.mtf_pipeline_runs(status);

CREATE OR REPLACE FUNCTION public.trigger_signal_pipeline_mtf(p_tier text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_url text; v_key text; v_secret text; v_headers jsonb;
  v_run_id uuid; v_req bigint; v_timeframes text[]; v_existing int;
BEGIN
  IF p_tier NOT IN ('daily','swing') THEN
    RAISE EXCEPTION 'tier tidak dikenal: %', p_tier;
  END IF;

  SELECT count(*) INTO v_existing FROM public.mtf_pipeline_runs WHERE tier = p_tier AND status = 'RUNNING';
  IF v_existing > 0 THEN
    RETURN; -- sudah ada run aktif utk tier ini, skip biar nggak dobel proses
  END IF;

  v_timeframes := CASE WHEN p_tier='daily' THEN ARRAY['H1','H4','D1'] ELSE ARRAY['D1','W1'] END;
  v_run_id := public.job_run_start('signal-pipeline-mtf-' || p_tier);

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason','vault secrets belum diset'));
    RETURN;
  END IF;
  v_headers := jsonb_build_object('Authorization','Bearer '||v_key,'Content-Type','application/json','x-worker-secret',v_secret);

  SELECT net.http_post(
    url := v_url || '/functions/v1/fetch-candles?timeframe=' || v_timeframes[1] || '&limit=1000',
    headers := v_headers, timeout_milliseconds := 240000
  ) INTO v_req;

  INSERT INTO public.mtf_pipeline_runs(tier, status, stage, timeframes, tf_index, pending_request_id, job_run_id, detail)
  VALUES (p_tier, 'RUNNING', 'fetch-candles', v_timeframes, 1, v_req, v_run_id, jsonb_build_object('timeframe', v_timeframes[1]));
END;
$function$;

CREATE OR REPLACE FUNCTION public.mtf_pipeline_poll()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  r record;
  v_row net._http_response%ROWTYPE;
  v_url text; v_key text; v_secret text; v_headers jsonb;
  v_req bigint; v_next_tf text;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.mtf_pipeline_runs WHERE status='RUNNING') THEN
    RETURN;
  END IF;

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  v_headers := jsonb_build_object('Authorization','Bearer '||v_key,'Content-Type','application/json','x-worker-secret',v_secret);

  FOR r IN SELECT * FROM public.mtf_pipeline_runs WHERE status='RUNNING' ORDER BY created_at LOOP
    SELECT * INTO v_row FROM net._http_response WHERE id = r.pending_request_id;

    IF NOT FOUND THEN
      IF now() - r.updated_at > interval '5 minutes' THEN
        PERFORM public.job_run_finish(r.job_run_id, 'ERROR', jsonb_build_object('stage', r.stage, 'reason', 'timeout menunggu net response (poller, >5menit)'));
        UPDATE public.mtf_pipeline_runs SET status='ERROR', updated_at=now() WHERE id = r.id;
      END IF;
      CONTINUE;
    END IF;

    IF v_row.error_msg IS NOT NULL OR v_row.status_code IS NULL OR v_row.status_code < 200 OR v_row.status_code >= 300 THEN
      PERFORM public.job_run_finish(r.job_run_id, 'ERROR', jsonb_build_object('stage', r.stage, 'status_code', v_row.status_code, 'error_msg', v_row.error_msg, 'content', left(v_row.content,500)));
      UPDATE public.mtf_pipeline_runs SET status='ERROR', updated_at=now() WHERE id = r.id;
      CONTINUE;
    END IF;

    IF r.stage = 'fetch-candles' THEN
      SELECT net.http_post(
        url := v_url || '/functions/v1/compute-indicators?timeframe=' || (r.timeframes[r.tf_index]) || '&limit=1000',
        headers := v_headers, timeout_milliseconds := 240000
      ) INTO v_req;
      UPDATE public.mtf_pipeline_runs SET stage='compute-indicators', pending_request_id=v_req, updated_at=now() WHERE id = r.id;

    ELSIF r.stage = 'compute-indicators' THEN
      IF r.tf_index < array_length(r.timeframes, 1) THEN
        v_next_tf := r.timeframes[r.tf_index + 1];
        SELECT net.http_post(
          url := v_url || '/functions/v1/fetch-candles?timeframe=' || v_next_tf || '&limit=1000',
          headers := v_headers, timeout_milliseconds := 240000
        ) INTO v_req;
        UPDATE public.mtf_pipeline_runs SET stage='fetch-candles', tf_index = r.tf_index + 1, pending_request_id=v_req, updated_at=now() WHERE id = r.id;
      ELSE
        SELECT net.http_post(
          url := v_url || '/functions/v1/generate-signals-mtf?tier=' || r.tier || '&limit=1000',
          headers := v_headers, timeout_milliseconds := 240000
        ) INTO v_req;
        UPDATE public.mtf_pipeline_runs SET stage='generate-signals-mtf', pending_request_id=v_req, updated_at=now() WHERE id = r.id;
      END IF;

    ELSIF r.stage = 'generate-signals-mtf' THEN
      PERFORM public.job_run_finish(r.job_run_id, 'SUCCESS', jsonb_build_object('tier', r.tier, 'note', 'full universe via async poller', 'result', left(v_row.content,1500)));
      UPDATE public.mtf_pipeline_runs SET status='SUCCESS', updated_at=now() WHERE id = r.id;
    END IF;
  END LOOP;
END;
$function$;

SELECT cron.schedule('mtf-pipeline-poller', '* * * * *', $$select public.mtf_pipeline_poll();$$);

-- Bersihkan artefak testing manual
DROP FUNCTION IF EXISTS public.temp_test_sleep_override();
SELECT cron.unschedule('temp-test-sleep');
