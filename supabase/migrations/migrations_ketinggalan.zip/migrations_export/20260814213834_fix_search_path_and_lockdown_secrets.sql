
-- Fix mutable search_path warnings (security advisor)
ALTER FUNCTION public.trigger_fetch_earnings_calendar() SET search_path = public;
ALTER FUNCTION public.trigger_fetch_fundamentals() SET search_path = public;
ALTER FUNCTION public.trigger_fetch_ipo_calendar() SET search_path = public;

-- Lock down internal_secrets: no client role should ever touch this table.
-- RLS was already enabled with no policy (deny-by-default), but we make it explicit
-- and revoke table grants from anon/authenticated so PostgREST can't even attempt it.
REVOKE ALL ON public.internal_secrets FROM anon, authenticated;
DROP POLICY IF EXISTS internal_secrets_no_access ON public.internal_secrets;
CREATE POLICY internal_secrets_no_access ON public.internal_secrets
  FOR ALL TO anon, authenticated USING (false) WITH CHECK (false);

-- ad_verifications: same treatment, only service_role (edge functions) should write/read this.
REVOKE ALL ON public.ad_verifications FROM anon;
DROP POLICY IF EXISTS ad_verifications_owner_read ON public.ad_verifications;
CREATE POLICY ad_verifications_owner_read ON public.ad_verifications
  FOR SELECT TO authenticated USING (user_id = auth.uid());
