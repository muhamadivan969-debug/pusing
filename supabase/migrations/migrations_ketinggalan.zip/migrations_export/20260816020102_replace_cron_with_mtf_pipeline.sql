-- Matikan 4 cron job lama (H1/H4/D1/W1 terpisah, generate-signals lama)
select cron.unschedule('signal-pipeline-h1-sesi1');
select cron.unschedule('signal-pipeline-h4-sesi1');
select cron.unschedule('signal-pipeline-d1-closing');
select cron.unschedule('signal-pipeline-w1-closing');

-- Daily tier: setiap hari kerja jam 15:25 WIB (08:25 UTC), setelah closing --
-- konsisten sama jadwal Worker 2 D1/W1 lama di dokumen.
select cron.schedule(
  'signal-pipeline-mtf-daily',
  '25 8 * * 1-5',
  $$select public.trigger_signal_pipeline_mtf('daily');$$
);

-- Swing tier: mingguan, Jumat jam 15:25 WIB (08:25 UTC) setelah closing minggu itu.
select cron.schedule(
  'signal-pipeline-mtf-swing',
  '25 8 * * 5',
  $$select public.trigger_signal_pipeline_mtf('swing');$$
);