-- Root cause revoke sebelumnya ga ngaruh: EXECUTE di-grant ke PUBLIC
-- (bukan cuma anon/authenticated), dan anon/authenticated otomatis warisan
-- akses dari PUBLIC di Postgres. Revoke dari PUBLIC di sini, service_role
-- & postgres tetap punya grant eksplisit terpisah jadi cron/internal tetap jalan.
REVOKE EXECUTE ON FUNCTION public.process_pending_corporate_actions() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.rls_auto_enable() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.trigger_generate_signal_reasoning() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.trigger_process_corporate_actions() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_push_on_new_notification() FROM PUBLIC;

-- Pastikan service_role & postgres tetap eksplisit bisa (buat cron/trigger internal)
GRANT EXECUTE ON FUNCTION public.process_pending_corporate_actions() TO service_role, postgres;
GRANT EXECUTE ON FUNCTION public.rls_auto_enable() TO service_role, postgres;
GRANT EXECUTE ON FUNCTION public.trigger_generate_signal_reasoning() TO service_role, postgres;
GRANT EXECUTE ON FUNCTION public.trigger_process_corporate_actions() TO service_role, postgres;
GRANT EXECUTE ON FUNCTION public.notify_push_on_new_notification() TO service_role, postgres;