-- Closing time berubah dari 15:25 WIB -> 16:15 WIB.
-- Semua jadwal cron di pg_cron pakai UTC (WIB = UTC+7).
-- Rantai baru: fetch closing quotes 16:05 WIB (09:05 UTC) -> generate signal closing 16:15 WIB (09:15 UTC) -> trending/sector rotation 16:20 WIB (09:20 UTC)

-- Fetch harga closing resmi: 15:20 WIB -> 16:05 WIB
SELECT cron.alter_job(job_id := 30, schedule := '5 9 * * 1-5');   -- fetch-quotes-close
SELECT cron.alter_job(job_id := 35, schedule := '5 9 * * 1-5');   -- fetch-index-close

-- Generate signal closing (D1/W1): 15:25 WIB -> 16:15 WIB
SELECT cron.alter_job(job_id := 58, schedule := '15 9 * * 1-5');  -- signal-pipeline-d1-closing
SELECT cron.alter_job(job_id := 59, schedule := '15 9 * * 5');    -- signal-pipeline-w1-closing (Jumat)

-- Trending score & sector rotation (setelah closing): 15:30 WIB -> 16:20 WIB
SELECT cron.alter_job(job_id := 18, schedule := '20 9 * * 1-5');  -- trending-score-daily
SELECT cron.alter_job(job_id := 46, schedule := '20 9 * * 1-5');  -- sector-rotation-daily
