-- ensure_wallet_current(p_user_id) menerima UUID bebas tanpa cek auth.uid(),
-- dan sebelumnya bisa dipanggil langsung via RPC oleh role authenticated —
-- artinya user manapun bisa memicu reset/ubah wallet user lain dengan
-- mengirim p_user_id milik orang lain. Fungsi ini seharusnya cuma dipanggil
-- secara internal oleh get_my_wallet() / RPC lain yang sudah validasi auth.uid().
-- Revoke tidak akan mematahkan get_my_wallet() karena panggilan nested dari
-- SECURITY DEFINER function jalan dengan privilese pemilik fungsi (postgres),
-- bukan privilese caller asli.

revoke execute on function public.ensure_wallet_current(uuid) from anon, authenticated, public;
