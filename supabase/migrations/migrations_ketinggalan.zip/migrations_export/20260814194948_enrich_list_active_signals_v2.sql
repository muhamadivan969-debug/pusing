
DROP FUNCTION IF EXISTS public.list_active_signals();

CREATE FUNCTION public.list_active_signals()
RETURNS TABLE (
  id uuid,
  direction text,
  status text,
  created_at timestamptz,
  stock_id uuid,
  ticker text,
  name text,
  entry_price numeric,
  buy_area_low numeric,
  buy_area_high numeric,
  tp1 numeric,
  tp2 numeric,
  stop_loss numeric,
  confidence_score numeric,
  current_price numeric
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    s.id, s.direction, s.status, s.created_at,
    st.id AS stock_id, st.ticker, st.name,
    s.entry_price, s.buy_area_low, s.buy_area_high,
    s.tp1, s.tp2, s.stop_loss, s.confidence_score,
    q.price AS current_price
  FROM public.signals s
  JOIN public.stocks st ON st.id = s.stock_id
  LEFT JOIN public.quotes q ON q.stock_id = st.id
  WHERE s.status IN ('ACTIVE', 'HIT_TP1')
    AND s.superseded_by IS NULL
    AND s.gate_passed = true
  ORDER BY s.created_at DESC;
$$;
