-- FIX (audit 15 Agustus 2026): generate-signal-reasoning dan generate-trending-reason
-- adalah edge function yang sudah dibuat & benar, tapi TIDAK PERNAH dipanggil oleh
-- pipeline atau cron manapun (trigger_signal_pipeline berhenti di generate-signals,
-- trigger_trending_score cuma manggil calculate_trending_scores). Akibatnya kolom
-- ai_reasoning di semua 1897 baris signals dan trending_reason di stocks selalu NULL,
-- jadi narasi AI di Kartu Sinyal & badge Trending tidak pernah muncul di frontend.
-- Migration ini menambahkan trigger function + cron job baru supaya kedua worker
-- jalan otomatis secara periodik (idempotent -- worker hanya proses baris yang
-- ai_reasoning/trending_reason-nya masih NULL, aman dipanggil berkali-kali).

CREATE OR REPLACE FUNCTION public.trigger_generate_signal_reasoning()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
DECLARE
  v_url text; v_key text; v_secret text; v_run_id uuid; v_req_id bigint;
BEGIN
  v_run_id := public.job_run_start('generate-signal-reasoning');
  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'vault/internal secrets belum diset'));
    RETURN;
  END IF;
  SELECT net.http_post(
    url := v_url || '/functions/v1/generate-signal-reasoning?limit=15',
    headers := jsonb_build_object('Authorization','Bearer ' || v_key,'Content-Type','application/json','x-worker-secret', v_secret),
    timeout_milliseconds := 90000
  ) INTO v_req_id;
  PERFORM public.job_run_finish(v_run_id, 'SUCCESS', jsonb_build_object('net_request_id', v_req_id, 'note', 'dispatched, menunggu reconcile'));
END;
$function$;

CREATE OR REPLACE FUNCTION public.trigger_generate_trending_reason()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
DECLARE
  v_url text; v_key text; v_secret text; v_run_id uuid; v_req_id bigint;
BEGIN
  v_run_id := public.job_run_start('generate-trending-reason');
  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'vault/internal secrets belum diset'));
    RETURN;
  END IF;
  SELECT net.http_post(
    url := v_url || '/functions/v1/generate-trending-reason?limit=10',
    headers := jsonb_build_object('Authorization','Bearer ' || v_key,'Content-Type','application/json','x-worker-secret', v_secret),
    timeout_milliseconds := 90000
  ) INTO v_req_id;
  PERFORM public.job_run_finish(v_run_id, 'SUCCESS', jsonb_build_object('net_request_id', v_req_id, 'note', 'dispatched, menunggu reconcile'));
END;
$function$;

-- Jadwal: setiap 10 menit selama jam bursa aktif (sesi 1 & sesi 2 WIB) supaya
-- reasoning sinyal baru & trending baru langsung ke-generate tanpa nunggu lama,
-- ditambah satu jalan lepas jam bursa (jam 08:00 WIB) buat nyapu sisa backlog.
SELECT cron.schedule('generate-signal-reasoning-session', '*/10 2-8 * * 1-5', $$SELECT public.trigger_generate_signal_reasoning();$$);
SELECT cron.schedule('generate-signal-reasoning-catchup', '0 1 * * 1-5', $$SELECT public.trigger_generate_signal_reasoning();$$);
SELECT cron.schedule('generate-trending-reason-daily', '30 9 * * 1-5', $$SELECT public.trigger_generate_trending_reason();$$);
