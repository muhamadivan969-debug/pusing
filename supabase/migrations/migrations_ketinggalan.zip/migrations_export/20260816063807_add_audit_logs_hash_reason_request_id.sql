
alter table public.audit_logs
  add column if not exists before_hash text,
  add column if not exists after_hash text,
  add column if not exists reason text,
  add column if not exists request_id uuid;
