
-- BUG: statement_timeout database default 2 menit, lebih pendek dari wait_for_net_response
-- yang bisa nunggu sampai 220 detik per stage. Akibatnya trigger_signal_pipeline_mtf selalu
-- ke-cancel oleh Postgres sebelum sempat nerima response dari fetch-candles/compute-indicators/
-- generate-signals-mtf saat diproses full 948 saham. Override statement_timeout khusus utk
-- function ini jadi 5 menit per statement (masih di bawah edge function runtime limit).
ALTER FUNCTION public.trigger_signal_pipeline_mtf(text) SET statement_timeout = '300s';
