-- Backfill market_cap yang kosong di quotes dari fundamentals
update public.quotes q
set market_cap = f.market_cap
from public.fundamentals f
where f.stock_id = q.stock_id and q.market_cap is null and f.market_cap is not null;

-- Trigger: setiap kali quotes di-insert/update, kalau market_cap kosong, isi otomatis dari fundamentals
create or replace function public.sync_quote_market_cap()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.market_cap is null then
    select f.market_cap into new.market_cap
    from public.fundamentals f
    where f.stock_id = new.stock_id;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_sync_quote_market_cap on public.quotes;
create trigger trg_sync_quote_market_cap
before insert or update on public.quotes
for each row execute function public.sync_quote_market_cap();

-- Trigger: setiap kali fundamentals di-update, dorong market_cap terbaru ke quotes terkait
create or replace function public.push_market_cap_to_quote()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.market_cap is not null then
    update public.quotes set market_cap = new.market_cap where stock_id = new.stock_id;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_push_market_cap_to_quote on public.fundamentals;
create trigger trg_push_market_cap_to_quote
after insert or update on public.fundamentals
for each row execute function public.push_market_cap_to_quote();