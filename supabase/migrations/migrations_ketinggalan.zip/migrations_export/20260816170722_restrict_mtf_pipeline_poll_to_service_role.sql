REVOKE EXECUTE ON FUNCTION public.mtf_pipeline_poll() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.mtf_pipeline_poll() TO service_role;