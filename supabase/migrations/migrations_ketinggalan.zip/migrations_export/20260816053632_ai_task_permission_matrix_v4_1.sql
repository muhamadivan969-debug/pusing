-- Spec v4.1 section 71: AI Task Permission Matrix -- deny-by-default, tidak ada FULL_ACCOUNT_ACCESS.
ALTER TABLE public.ai_tasks
  ADD COLUMN IF NOT EXISTS action text CHECK (action IS NULL OR action = ANY (ARRAY[
    'READ_MARKET_DATA'::text,
    'READ_WATCHLIST'::text,
    'READ_SIGNALS'::text,
    'READ_NEWS'::text,
    'CREATE_TRADING_PLAN'::text,
    'UPDATE_WATCHLIST'::text,
    'CREATE_ALERT'::text,
    'SEND_NOTIFICATION'::text
  ])),
  ADD COLUMN IF NOT EXISTS input jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS permission_decision text DEFAULT 'PENDING' CHECK (permission_decision = ANY (ARRAY['ALLOW'::text,'DENY'::text,'PENDING'::text])),
  ADD COLUMN IF NOT EXISTS confirmation_required boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS result jsonb,
  ADD COLUMN IF NOT EXISTS audit_id uuid REFERENCES public.audit_logs(id),
  ADD COLUMN IF NOT EXISTS completed_at timestamptz;

COMMENT ON COLUMN public.ai_tasks.action IS 'Deny-by-default permission scope untuk AI Task, sesuai spec v4.1 section 71. Tidak ada FULL_ACCOUNT_ACCESS.';
COMMENT ON COLUMN public.ai_tasks.permission_decision IS 'Keputusan permission check saat task dieksekusi -- ALLOW/DENY/PENDING';

-- Default: task lama (kalau ada) tetap PENDING sampai direview, tidak otomatis ALLOW.
INSERT INTO public.audit_logs (action, entity_type, detail)
VALUES ('schema_migration', 'ai_tasks', jsonb_build_object(
  'migration', 'ai_task_permission_matrix_v4_1',
  'note', 'Menambahkan kolom permission matrix deny-by-default ke ai_tasks sesuai section 71.'
));