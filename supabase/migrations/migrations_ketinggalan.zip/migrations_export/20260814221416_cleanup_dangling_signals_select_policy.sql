-- Policy "signals readable by all" (qual=true) ini nyangkut lagi di tabel signals
-- (kemungkinan ke-recreate oleh migration "fix_signals_missing_rls_select_policy"
-- tanpa sadar bahwa itu memang sengaja ditutup demi paywall).
-- Saat ini TIDAK exploitable karena anon/authenticated tidak punya GRANT SELECT
-- di tabel signals (sudah di-revoke), tapi policy basi ini bahaya kalau suatu saat
-- ada yang re-grant SELECT tanpa sadar policy lama masih longgar (qual=true).
-- Akses publik ke data sinyal HARUS lewat view signals_public atau RPC
-- get_signal_for_stock / get_signal_history / list_active_signals.
DROP POLICY IF EXISTS "signals readable by all" ON public.signals;

-- Pastikan grant tetap terkunci (idempotent safety net)
REVOKE SELECT ON public.signals FROM anon, authenticated;
