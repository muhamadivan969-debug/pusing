
-- PIVOT PRODUK (16 Agustus 2026, keputusan user): Sinyal AI tidak lagi klaim
-- Win Rate/Confidence Score (setelah 6+ formula dicoba, tidak ada yang lolos
-- gate 55% WR -- lihat backtest_runs/signal_engine_versions). Model baru ala
-- Neurobro: kartu sinyal cuma nampilin level struktural (support, resistance,
-- buy area, SL, TP1, TP2) tanpa klaim statistik. Gate backtest jadi tidak
-- relevan lagi untuk fitur ini karena tidak ada lagi angka yang perlu
-- divalidasi -- makanya gate_passed dihapus, bukan cuma diset default true.
--
-- Sekaligus upgrade ke multi-timeframe confluence:
--   Daily = H1 (entry/SL) + H4 (konfirmasi) + D1 (bias/TP)
--   Swing = D1 (entry/SL) + W1 (bias/TP)
-- Kalau timeframe-timeframe itu tidak selaras, TIDAK ADA sinyal yang dibuat
-- sama sekali (bukan sinyal dengan warning) -- konsisten sama prinsip HOLD
-- yang sudah ada (dok 5.5/6.6): diam itu valid state, bukan cuma menang/kalah.

alter table public.signals drop column if exists confidence_score;
alter table public.signals drop column if exists gate_passed;

alter table public.signals add column if not exists signal_tier text
  check (signal_tier in ('daily','swing'));

alter table public.signals add column if not exists bias_timeframe text;
alter table public.signals add column if not exists confirm_timeframe text;
alter table public.signals add column if not exists entry_timeframe text;

comment on column public.signals.signal_tier is 'daily = H1/H4/D1 confluence, holding beberapa hari. swing = D1/W1 confluence, holding 1-4 minggu.';
comment on column public.signals.bias_timeframe is 'timeframe penentu arah/bias utama (D1 untuk daily, W1 untuk swing) -- sumber TP1/TP2.';
comment on column public.signals.confirm_timeframe is 'timeframe konfirmasi struktur menengah (H4 untuk daily, null untuk swing).';
comment on column public.signals.entry_timeframe is 'timeframe timing entry presisi (H1 untuk daily, D1 untuk swing) -- sumber Stop Loss.';

create index if not exists idx_signals_tier_status on public.signals (signal_tier, status) where superseded_by is null;
