
CREATE OR REPLACE FUNCTION public.get_for_you_stocks(p_limit int DEFAULT 10)
RETURNS TABLE (
  stock_id uuid,
  ticker text,
  name text,
  price numeric,
  change_percent numeric,
  signal_direction text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_risk_profile text;
  v_cap_min numeric;
  v_cap_max numeric;
BEGIN
  SELECT p.risk_profile INTO v_risk_profile FROM public.profiles p WHERE p.id = auth.uid();

  IF v_risk_profile = 'KONSERVATIF' THEN
    v_cap_min := 10000000000000; v_cap_max := NULL;
  ELSIF v_risk_profile = 'MODERAT' THEN
    v_cap_min := 2000000000000; v_cap_max := 10000000000000;
  ELSE
    v_cap_min := 0; v_cap_max := 2000000000000;
  END IF;

  RETURN QUERY
  SELECT s.id, s.ticker, s.name, q.price,
    round(((q.price - q.previous_close) / NULLIF(q.previous_close, 0)) * 100, 2) AS change_percent,
    sig.direction
  FROM public.stocks s
  JOIN public.quotes q ON q.stock_id = s.id
  LEFT JOIN LATERAL (
    SELECT sig_inner.direction FROM public.signals sig_inner
    WHERE sig_inner.stock_id = s.id AND sig_inner.status IN ('ACTIVE','HIT_TP1') AND sig_inner.superseded_by IS NULL
    ORDER BY sig_inner.created_at DESC LIMIT 1
  ) sig ON true
  WHERE s.is_active = true
    AND q.market_cap >= v_cap_min
    AND (v_cap_max IS NULL OR q.market_cap < v_cap_max)
  ORDER BY (sig.direction = 'BUY') DESC NULLS LAST, q.market_cap DESC
  LIMIT p_limit;
END;
$$;
