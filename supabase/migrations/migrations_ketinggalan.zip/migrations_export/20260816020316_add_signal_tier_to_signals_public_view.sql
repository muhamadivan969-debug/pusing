create or replace view public.signals_public as
 SELECT id,
    stock_id,
    direction,
    timeframe,
    status,
    created_at,
    resolved_at,
    superseded_by,
    signal_tier
   FROM signals;