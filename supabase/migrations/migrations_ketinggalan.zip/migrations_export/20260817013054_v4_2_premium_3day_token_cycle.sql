-- Spec v4.2 section 10.2/10.3: Free reset tiap hari (5 token), Premium reset tiap 3 hari (50 token).
-- deduct_token() sebelumnya reset premium jadi 50 SETIAP HARI (bukan tiap 3 hari) -- dikoreksi di sini.
CREATE OR REPLACE FUNCTION public.deduct_token(p_type text, p_reference_id uuid DEFAULT NULL::uuid)
 RETURNS TABLE(balance integer, already_charged boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE
  v_user_id uuid := auth.uid();
  v_wallet_id uuid;
  v_balance integer;
  v_balance_before integer;
  v_last_reset date;
  v_today_wib date := (now() AT TIME ZONE 'Asia/Jakarta')::date;
  v_is_premium boolean;
  v_daily_grant integer;
  v_period_days integer;
  v_existing_id uuid;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;
  IF p_type IS NULL OR p_type = '' THEN
    RAISE EXCEPTION 'INVALID_TYPE';
  END IF;

  IF p_reference_id IS NOT NULL THEN
    SELECT tt.id INTO v_existing_id
    FROM public.token_transactions tt
    JOIN public.token_wallets tw ON tw.id = tt.wallet_id
    WHERE tw.user_id = v_user_id AND tt.reference_id = p_reference_id AND tt.type = p_type
    LIMIT 1;

    IF v_existing_id IS NOT NULL THEN
      SELECT tw.balance INTO v_balance FROM public.token_wallets tw WHERE tw.user_id = v_user_id;
      RETURN QUERY SELECT v_balance, true;
      RETURN;
    END IF;
  END IF;

  SELECT p.is_premium INTO v_is_premium FROM public.profiles p WHERE p.id = v_user_id;
  v_daily_grant := CASE WHEN v_is_premium THEN 50 ELSE 5 END;
  v_period_days := CASE WHEN v_is_premium THEN 3 ELSE 1 END;

  SELECT tw.id, tw.balance, tw.last_reset_date INTO v_wallet_id, v_balance, v_last_reset
  FROM public.token_wallets tw
  WHERE tw.user_id = v_user_id
  FOR UPDATE;

  IF v_wallet_id IS NULL THEN
    INSERT INTO public.token_wallets (user_id, balance, last_reset_date)
    VALUES (v_user_id, v_daily_grant, v_today_wib)
    RETURNING token_wallets.id, token_wallets.balance, token_wallets.last_reset_date
    INTO v_wallet_id, v_balance, v_last_reset;
  ELSIF v_today_wib - v_last_reset >= v_period_days THEN
    UPDATE public.token_wallets AS tw
      SET balance = v_daily_grant, last_reset_date = v_today_wib
      WHERE tw.id = v_wallet_id
      RETURNING tw.balance INTO v_balance;
  END IF;

  IF v_balance <= 0 THEN
    RAISE EXCEPTION 'INSUFFICIENT_TOKENS';
  END IF;

  v_balance_before := v_balance;

  UPDATE public.token_wallets AS tw SET balance = tw.balance - 1
    WHERE tw.id = v_wallet_id RETURNING tw.balance INTO v_balance;

  INSERT INTO public.token_transactions (wallet_id, amount, type, reference_id, balance_before, balance_after)
  VALUES (v_wallet_id, -1, p_type, p_reference_id, v_balance_before, v_balance);

  RETURN QUERY SELECT v_balance, false;
END;
$function$
