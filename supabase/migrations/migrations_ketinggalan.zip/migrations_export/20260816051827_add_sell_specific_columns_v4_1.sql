-- Sesuai spec v4.1 Section 24: signals wajib punya kolom BUY-specific dan SELL-specific.
-- Saat ini tabel signals hanya punya kolom BUY-specific. Tambahkan kolom SELL-specific.

ALTER TABLE public.signals
  ADD COLUMN IF NOT EXISTS bearish_type text
    CHECK (bearish_type IS NULL OR bearish_type = ANY (ARRAY[
      'BEARISH_REJECTION'::text,
      'BEARISH_BREAKDOWN'::text,
      'BEARISH_DISTRIBUTION_INDICATION'::text,
      'BEARISH_CONTINUATION'::text
    ])),
  ADD COLUMN IF NOT EXISTS bearish_trigger numeric,
  ADD COLUMN IF NOT EXISTS invalidation numeric,
  ADD COLUMN IF NOT EXISTS downside_support_1 numeric,
  ADD COLUMN IF NOT EXISTS downside_support_2 numeric;

COMMENT ON COLUMN public.signals.bearish_type IS 'Tipe bearish untuk direction=SELL, sesuai spec v4.1 section 2.2';
COMMENT ON COLUMN public.signals.bearish_trigger IS 'Bearish trigger/area untuk direction=SELL';
COMMENT ON COLUMN public.signals.invalidation IS 'Invalidation level untuk direction=SELL (kondisi bearish batal)';
COMMENT ON COLUMN public.signals.downside_support_1 IS 'Support downside berikutnya #1 untuk direction=SELL';
COMMENT ON COLUMN public.signals.downside_support_2 IS 'Support downside berikutnya #2 untuk direction=SELL';

-- Pastikan status masih relevan untuk BUY & SELL (HIT_TP1/HIT_TP2/HIT_SL berlaku utk BUY;
-- untuk SELL kita reuse status generik lifecycle -- tidak diubah di migration ini karena
-- perlu keputusan mapping status SELL, dicatat sebagai TODO di audit_logs).

INSERT INTO public.audit_logs (action, entity_type, detail)
VALUES (
  'schema_migration',
  'signals',
  jsonb_build_object(
    'migration', 'add_sell_specific_columns_v4_1',
    'note', 'Menambahkan kolom SELL-specific (bearish_type, bearish_trigger, invalidation, downside_support_1/2) sesuai struktur v4.1 section 24. TODO: mapping status lifecycle khusus SELL (BEARISH_ACTIVE/INVALIDATED/dst) belum diputuskan.'
  )
);