
-- Fungsi refund token: dipakai kalau proses (misal AI Chat) sudah motong token tapi gagal total,
-- supaya user tidak dirugikan. Aman terhadap duplikat lewat reference_id+type yang sama.
CREATE OR REPLACE FUNCTION public.refund_token(p_type text, p_reference_id uuid DEFAULT NULL::uuid)
 RETURNS TABLE(balance integer, refunded boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE
  v_user_id uuid := auth.uid();
  v_wallet_id uuid;
  v_balance integer;
  v_already boolean;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'NOT_AUTHENTICATED';
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.token_transactions tt
    JOIN public.token_wallets tw ON tw.id = tt.wallet_id
    WHERE tw.user_id = v_user_id AND tt.reference_id = p_reference_id AND tt.type = p_type
  ) INTO v_already;

  IF v_already THEN
    SELECT tw.balance INTO v_balance FROM public.token_wallets tw WHERE tw.user_id = v_user_id;
    RETURN QUERY SELECT v_balance, false;
    RETURN;
  END IF;

  UPDATE public.token_wallets AS tw SET balance = tw.balance + 1
    WHERE tw.user_id = v_user_id
    RETURNING tw.id, tw.balance INTO v_wallet_id, v_balance;

  IF v_wallet_id IS NULL THEN
    RETURN QUERY SELECT NULL::integer, false;
    RETURN;
  END IF;

  INSERT INTO public.token_transactions (wallet_id, amount, type, reference_id)
  VALUES (v_wallet_id, 1, p_type, p_reference_id);

  RETURN QUERY SELECT v_balance, true;
END;
$function$;
