-- FITUR BARU (15 Agustus 2026): Web Push Notification.
-- Sebelumnya "notifications" cuma jadi baris di database yang ditampilkan
-- kalau user buka halaman /notifikasi secara manual -- tidak ada notifikasi
-- yang benar-benar nyampe ke HP/browser user saat app tertutup (padahal
-- dokumen 5.8/5.9/17 menyiratkan notifikasi push sungguhan). Sekarang
-- ditambahkan: tabel penyimpan push subscription per user + trigger
-- otomatis kirim Web Push tiap ada baris baru masuk ke `notifications`,
-- selama user sudah subscribe DAN preferensi kategori terkait masih ON.

CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint text NOT NULL,
  p256dh text NOT NULL,
  auth text NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, endpoint)
);

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY push_subscriptions_select_own ON public.push_subscriptions
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY push_subscriptions_insert_own ON public.push_subscriptions
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY push_subscriptions_delete_own ON public.push_subscriptions
  FOR DELETE USING (auth.uid() = user_id);

CREATE INDEX idx_push_subscriptions_user_id ON public.push_subscriptions(user_id);

-- Map kategori notifikasi -> kolom preference, dipakai buat cek sebelum kirim push.
CREATE OR REPLACE FUNCTION public.notify_push_on_new_notification()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
DECLARE
  v_pref record;
  v_allowed boolean := true;
  v_url text; v_key text; v_secret text; v_req_id bigint;
BEGIN
  SELECT * INTO v_pref FROM public.notification_preferences WHERE user_id = NEW.user_id;

  IF v_pref IS NOT NULL THEN
    IF v_pref.master_enabled = false THEN
      v_allowed := false;
    ELSIF NEW.category = 'market' AND v_pref.market_alerts = false THEN v_allowed := false;
    ELSIF NEW.category = 'signal' AND v_pref.signal_alerts = false THEN v_allowed := false;
    ELSIF NEW.category = 'news' AND v_pref.news_updates = false THEN v_allowed := false;
    ELSIF NEW.category = 'economic' AND v_pref.economic_events = false THEN v_allowed := false;
    ELSIF NEW.category = 'morning_briefing' AND v_pref.morning_briefing = false THEN v_allowed := false;
    ELSIF NEW.category = 'unusual_activity' AND v_pref.unusual_activity_alert = false THEN v_allowed := false;
    END IF;
  END IF;

  IF NOT v_allowed THEN
    RETURN NEW;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.push_subscriptions WHERE user_id = NEW.user_id) THEN
    RETURN NEW;
  END IF;

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT net.http_post(
    url := v_url || '/functions/v1/send-web-push',
    headers := jsonb_build_object('Authorization','Bearer ' || v_key,'Content-Type','application/json','x-worker-secret', v_secret),
    body := jsonb_build_object(
      'user_id', NEW.user_id,
      'title', NEW.title,
      'body', NEW.body,
      'category', NEW.category,
      'reference_id', NEW.reference_id
    ),
    timeout_milliseconds := 15000
  ) INTO v_req_id;

  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_notify_push_on_new_notification ON public.notifications;
CREATE TRIGGER trg_notify_push_on_new_notification
  AFTER INSERT ON public.notifications
  FOR EACH ROW EXECUTE FUNCTION public.notify_push_on_new_notification();
