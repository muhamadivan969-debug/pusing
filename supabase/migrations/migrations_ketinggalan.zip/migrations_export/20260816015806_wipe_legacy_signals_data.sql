-- Hapus data hasil evaluasi & sinyal formula lama (semua belum lolos gate,
-- semua signal_tier IS NULL -- belum satupun dari generate-signals-mtf).
delete from public.signal_results
where signal_id in (select id from public.signals where signal_tier is null);

delete from public.saved_signals; -- snapshot lama, tidak relevan lagi dengan model baru

delete from public.signals where signal_tier is null;