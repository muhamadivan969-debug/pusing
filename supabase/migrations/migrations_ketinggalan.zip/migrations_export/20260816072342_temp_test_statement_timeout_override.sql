
CREATE OR REPLACE FUNCTION public.temp_test_sleep_override()
RETURNS text
LANGUAGE plpgsql
SET statement_timeout = '300s'
AS $$
BEGIN
  PERFORM pg_sleep(150);
  RETURN 'survived 150s';
END;
$$;
