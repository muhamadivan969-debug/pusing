-- Spec v4.1 section 72.3: Signal Pipeline Observability -- tiap stage harus terlihat,
-- kegagalan satu stage tidak boleh disamarkan sebagai NO SIGNAL.
CREATE TABLE IF NOT EXISTS public.signal_pipeline_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id uuid REFERENCES public.stocks(id),
  tier text CHECK (tier = ANY (ARRAY['daily'::text,'swing'::text])),
  stage text NOT NULL CHECK (stage = ANY (ARRAY[
    'ingestion'::text,'quality'::text,'indicator'::text,'structure'::text,
    'confluence'::text,'signal'::text,'snapshot'::text,'notification'::text
  ])),
  status text NOT NULL CHECK (status = ANY (ARRAY['OK'::text,'FAILED'::text,'SKIPPED'::text])),
  detail jsonb,
  job_run_id uuid REFERENCES public.job_runs(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.signal_pipeline_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "signal_pipeline_events_admin_select" ON public.signal_pipeline_events
  FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true));
CREATE POLICY "signal_pipeline_events_service_write" ON public.signal_pipeline_events
  FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE INDEX IF NOT EXISTS idx_signal_pipeline_events_stage ON public.signal_pipeline_events (stage, status, created_at DESC);

-- Spec v4.1 section 74: Security Acceptance Matrix -- checklist wajib diuji sebelum production.
CREATE TABLE IF NOT EXISTS public.security_acceptance_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  threat text NOT NULL UNIQUE,
  expected_behavior text NOT NULL,
  test_status text NOT NULL DEFAULT 'NOT_TESTED' CHECK (test_status = ANY (ARRAY['NOT_TESTED'::text,'PASS'::text,'FAIL'::text])),
  last_tested_at timestamptz,
  last_tested_by uuid REFERENCES public.profiles(id),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.security_acceptance_checks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "security_acceptance_checks_admin_all" ON public.security_acceptance_checks
  FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

INSERT INTO public.security_acceptance_checks (threat, expected_behavior) VALUES
  ('Unauthorized object access', '403/404 sesuai policy'),
  ('Token double-spend', 'Atomic rejection'),
  ('Duplicate payment webhook', 'No duplicate entitlement'),
  ('Fake ad reward', 'No reward'),
  ('Replay reward', 'No duplicate reward'),
  ('Prompt injection', 'External content ignored as instruction'),
  ('Malicious upload', 'Rejected/safely isolated'),
  ('Oversized upload', 'Rejected'),
  ('Invalid MIME', 'Rejected'),
  ('SSRF attempt', 'Blocked'),
  ('Rate abuse', 'Throttled'),
  ('Expired session', 'Re-authentication required')
ON CONFLICT (threat) DO NOTHING;