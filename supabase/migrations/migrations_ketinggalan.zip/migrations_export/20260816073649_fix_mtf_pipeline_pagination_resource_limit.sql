
-- BUG: limit=1000 sekaligus bikin edge function kena WORKER_RESOURCE_LIMIT (compute
-- Supabase Edge Function nggak cukup buat proses 1000 saham dalam satu invocation).
-- Fix: pecah jadi halaman 100 saham per panggilan, poller otomatis lanjut ke halaman
-- berikutnya (offset += 100) sampai seluruh saham aktif ke-cover, baru pindah stage.
ALTER TABLE public.mtf_pipeline_runs ADD COLUMN IF NOT EXISTS offset_val int NOT NULL DEFAULT 0;

CREATE OR REPLACE FUNCTION public.trigger_signal_pipeline_mtf(p_tier text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_url text; v_key text; v_secret text; v_headers jsonb;
  v_run_id uuid; v_req bigint; v_timeframes text[]; v_existing int;
BEGIN
  IF p_tier NOT IN ('daily','swing') THEN
    RAISE EXCEPTION 'tier tidak dikenal: %', p_tier;
  END IF;

  SELECT count(*) INTO v_existing FROM public.mtf_pipeline_runs WHERE tier = p_tier AND status = 'RUNNING';
  IF v_existing > 0 THEN
    RETURN;
  END IF;

  v_timeframes := CASE WHEN p_tier='daily' THEN ARRAY['H1','H4','D1'] ELSE ARRAY['D1','W1'] END;
  v_run_id := public.job_run_start('signal-pipeline-mtf-' || p_tier);

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason','vault secrets belum diset'));
    RETURN;
  END IF;
  v_headers := jsonb_build_object('Authorization','Bearer '||v_key,'Content-Type','application/json','x-worker-secret',v_secret);

  SELECT net.http_post(
    url := v_url || '/functions/v1/fetch-candles?timeframe=' || v_timeframes[1] || '&offset=0&limit=100',
    headers := v_headers, timeout_milliseconds := 240000
  ) INTO v_req;

  INSERT INTO public.mtf_pipeline_runs(tier, status, stage, timeframes, tf_index, offset_val, pending_request_id, job_run_id, detail)
  VALUES (p_tier, 'RUNNING', 'fetch-candles', v_timeframes, 1, 0, v_req, v_run_id, jsonb_build_object('timeframe', v_timeframes[1]));
END;
$function$;

CREATE OR REPLACE FUNCTION public.mtf_pipeline_poll()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  r record;
  v_row net._http_response%ROWTYPE;
  v_url text; v_key text; v_secret text; v_headers jsonb;
  v_req bigint; v_next_tf text; v_page_total int; v_next_offset int;
  PAGE_SIZE constant int := 100;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.mtf_pipeline_runs WHERE status='RUNNING') THEN
    RETURN;
  END IF;

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  v_headers := jsonb_build_object('Authorization','Bearer '||v_key,'Content-Type','application/json','x-worker-secret',v_secret);

  FOR r IN SELECT * FROM public.mtf_pipeline_runs WHERE status='RUNNING' ORDER BY created_at LOOP
    SELECT * INTO v_row FROM net._http_response WHERE id = r.pending_request_id;

    IF NOT FOUND THEN
      IF now() - r.updated_at > interval '5 minutes' THEN
        PERFORM public.job_run_finish(r.job_run_id, 'ERROR', jsonb_build_object('stage', r.stage, 'reason', 'timeout menunggu net response (poller, >5menit)'));
        UPDATE public.mtf_pipeline_runs SET status='ERROR', updated_at=now() WHERE id = r.id;
      END IF;
      CONTINUE;
    END IF;

    IF v_row.error_msg IS NOT NULL OR v_row.status_code IS NULL OR v_row.status_code < 200 OR v_row.status_code >= 300 THEN
      PERFORM public.job_run_finish(r.job_run_id, 'ERROR', jsonb_build_object('stage', r.stage, 'offset', r.offset_val, 'status_code', v_row.status_code, 'error_msg', v_row.error_msg, 'content', left(v_row.content,500)));
      UPDATE public.mtf_pipeline_runs SET status='ERROR', updated_at=now() WHERE id = r.id;
      CONTINUE;
    END IF;

    v_page_total := COALESCE((v_row.content::jsonb ->> 'total')::int, 0);

    IF r.stage IN ('fetch-candles','compute-indicators') AND v_page_total >= PAGE_SIZE THEN
      -- masih ada halaman lagi di stage yang sama
      v_next_offset := r.offset_val + PAGE_SIZE;
      SELECT net.http_post(
        url := v_url || '/functions/v1/' || r.stage || '?timeframe=' || (r.timeframes[r.tf_index]) || '&offset=' || v_next_offset || '&limit=' || PAGE_SIZE,
        headers := v_headers, timeout_milliseconds := 240000
      ) INTO v_req;
      UPDATE public.mtf_pipeline_runs SET offset_val=v_next_offset, pending_request_id=v_req, updated_at=now() WHERE id = r.id;

    ELSIF r.stage = 'fetch-candles' THEN
      -- halaman fetch-candles utk timeframe ini selesai semua -> lanjut compute-indicators dari offset 0
      SELECT net.http_post(
        url := v_url || '/functions/v1/compute-indicators?timeframe=' || (r.timeframes[r.tf_index]) || '&offset=0&limit=' || PAGE_SIZE,
        headers := v_headers, timeout_milliseconds := 240000
      ) INTO v_req;
      UPDATE public.mtf_pipeline_runs SET stage='compute-indicators', offset_val=0, pending_request_id=v_req, updated_at=now() WHERE id = r.id;

    ELSIF r.stage = 'compute-indicators' THEN
      IF r.tf_index < array_length(r.timeframes, 1) THEN
        v_next_tf := r.timeframes[r.tf_index + 1];
        SELECT net.http_post(
          url := v_url || '/functions/v1/fetch-candles?timeframe=' || v_next_tf || '&offset=0&limit=' || PAGE_SIZE,
          headers := v_headers, timeout_milliseconds := 240000
        ) INTO v_req;
        UPDATE public.mtf_pipeline_runs SET stage='fetch-candles', tf_index = r.tf_index + 1, offset_val=0, pending_request_id=v_req, updated_at=now() WHERE id = r.id;
      ELSE
        SELECT net.http_post(
          url := v_url || '/functions/v1/generate-signals-mtf?tier=' || r.tier || '&offset=0&limit=' || PAGE_SIZE,
          headers := v_headers, timeout_milliseconds := 240000
        ) INTO v_req;
        UPDATE public.mtf_pipeline_runs SET stage='generate-signals-mtf', offset_val=0, pending_request_id=v_req, updated_at=now() WHERE id = r.id;
      END IF;

    ELSIF r.stage = 'generate-signals-mtf' AND v_page_total >= PAGE_SIZE THEN
      v_next_offset := r.offset_val + PAGE_SIZE;
      SELECT net.http_post(
        url := v_url || '/functions/v1/generate-signals-mtf?tier=' || r.tier || '&offset=' || v_next_offset || '&limit=' || PAGE_SIZE,
        headers := v_headers, timeout_milliseconds := 240000
      ) INTO v_req;
      UPDATE public.mtf_pipeline_runs SET offset_val=v_next_offset, pending_request_id=v_req, updated_at=now() WHERE id = r.id;

    ELSIF r.stage = 'generate-signals-mtf' THEN
      PERFORM public.job_run_finish(r.job_run_id, 'SUCCESS', jsonb_build_object('tier', r.tier, 'note', 'full universe via async paginated poller'));
      UPDATE public.mtf_pipeline_runs SET status='SUCCESS', updated_at=now() WHERE id = r.id;
    END IF;
  END LOOP;
END;
$function$;
