-- Add missing covering index for FK
CREATE INDEX IF NOT EXISTS idx_idx_eod_uploads_uploaded_by ON public.idx_eod_uploads (uploaded_by);

-- Fix RLS initplan perf issue: wrap auth.<fn>() calls in (select ...) so they evaluate once, not per-row
DO $$
DECLARE
  pol RECORD;
BEGIN
  FOR pol IN
    SELECT polname, pg_get_expr(polqual, polrelid) AS qual, pg_get_expr(polwithcheck, polrelid) AS withcheck
    FROM pg_policy
    WHERE polrelid = 'public.idx_eod_uploads'::regclass
  LOOP
    RAISE NOTICE 'policy % qual=% withcheck=%', pol.polname, pol.qual, pol.withcheck;
  END LOOP;
END $$;