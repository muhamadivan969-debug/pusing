
-- 1) gate_passed harus immutable (snapshot saat sinyal dibuat), bukan dihitung ulang tiap UPDATE.
--    Hapus trigger versi UPDATE, sisakan hanya INSERT.
DROP TRIGGER IF EXISTS trg_set_signal_gate_passed ON public.signals;

CREATE TRIGGER trg_set_signal_gate_passed
  BEFORE INSERT ON public.signals
  FOR EACH ROW
  EXECUTE FUNCTION public.set_signal_gate_passed();

-- 2) Backfill data lama yang gate_passed-nya kadung ke-reset jadi false oleh bug di atas.
--    Pakai status approval formula_version+timeframe yang berlaku saat ini sebagai acuan terbaik yang tersedia.
UPDATE public.signals s
SET gate_passed = COALESCE(sev.is_approved, false)
FROM public.signal_engine_versions sev
WHERE sev.formula_version = s.formula_version
  AND sev.timeframe = s.timeframe
  AND s.gate_passed IS DISTINCT FROM COALESCE(sev.is_approved, false);
