-- Spec v4.1 section 69: News Intelligence Evidence Contract.
CREATE TABLE IF NOT EXISTS public.news_issuer_mapping (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  article_id uuid NOT NULL REFERENCES public.news(id) ON DELETE CASCADE,
  stock_id uuid NOT NULL REFERENCES public.stocks(id) ON DELETE CASCADE,
  mapping_method text NOT NULL CHECK (mapping_method = ANY (ARRAY[
    'EXPLICIT_TICKER'::text,
    'EXPLICIT_ISSUER_NAME'::text,
    'CORPORATE_ACTION'::text,
    'ENTITY_MATCH'::text,
    'INDUSTRY_CONTEXT'::text,
    'LOCATION_CONTEXT'::text
  ])),
  mapping_confidence text NOT NULL DEFAULT 'MEDIUM' CHECK (mapping_confidence = ANY (ARRAY['HIGH'::text,'MEDIUM'::text,'LOW'::text])),
  impact text NOT NULL DEFAULT 'INFORMATIONAL' CHECK (impact = ANY (ARRAY[
    'POTENTIALLY_POSITIVE'::text,
    'POTENTIALLY_NEGATIVE'::text,
    'MIXED_UNCLEAR'::text,
    'INFORMATIONAL'::text
  ])),
  source_evidence text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (article_id, stock_id)
);

ALTER TABLE public.news_issuer_mapping ENABLE ROW LEVEL SECURITY;

CREATE POLICY "news_issuer_mapping_select_all" ON public.news_issuer_mapping
  FOR SELECT USING (true);

CREATE POLICY "news_issuer_mapping_service_write" ON public.news_issuer_mapping
  FOR ALL USING (auth.role() = 'service_role') WITH CHECK (auth.role() = 'service_role');

CREATE INDEX IF NOT EXISTS idx_news_issuer_mapping_stock ON public.news_issuer_mapping (stock_id);
CREATE INDEX IF NOT EXISTS idx_news_issuer_mapping_article ON public.news_issuer_mapping (article_id);