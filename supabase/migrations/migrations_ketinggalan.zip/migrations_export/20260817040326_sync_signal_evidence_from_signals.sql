-- Sinkronisasi otomatis signals.evidence (JSONB gabungan) -> tabel signal_evidence
-- ternormalisasi (Section 18.3 spec) untuk audit trail yang stabil per-field.

CREATE OR REPLACE FUNCTION public.sync_signal_evidence()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.evidence IS NULL THEN
    RETURN NEW;
  END IF;

  INSERT INTO public.signal_evidence (
    id, signal_id, structure, support, resistance, "trigger",
    invalidation, timeframes, data_quality, formula_version, generated_at, created_at
  )
  VALUES (
    gen_random_uuid(),
    NEW.id,
    NEW.evidence->'structure',
    NEW.evidence->'support',
    NEW.evidence->'resistance',
    NEW.evidence->'trigger',
    NEW.evidence->'invalidation',
    NEW.evidence->'timeframes',
    NEW.evidence->'data_quality',
    COALESCE(NEW.evidence->>'formula_version', NEW.formula_version),
    COALESCE((NEW.evidence->>'generated_at')::timestamptz, NEW.created_at, now()),
    now()
  )
  ON CONFLICT (signal_id) DO UPDATE SET
    structure = EXCLUDED.structure,
    support = EXCLUDED.support,
    resistance = EXCLUDED.resistance,
    "trigger" = EXCLUDED."trigger",
    invalidation = EXCLUDED.invalidation,
    timeframes = EXCLUDED.timeframes,
    data_quality = EXCLUDED.data_quality,
    formula_version = EXCLUDED.formula_version,
    generated_at = EXCLUDED.generated_at;

  RETURN NEW;
END;
$$;

-- signal_evidence butuh unique constraint di signal_id supaya ON CONFLICT di atas jalan
-- (audit trail 1 baris evidence terkini per sinyal; histori revisi tetap ada di audit_logs)
ALTER TABLE public.signal_evidence
  ADD CONSTRAINT signal_evidence_signal_id_key UNIQUE (signal_id);

DROP TRIGGER IF EXISTS trg_sync_signal_evidence ON public.signals;
CREATE TRIGGER trg_sync_signal_evidence
  AFTER INSERT OR UPDATE OF evidence ON public.signals
  FOR EACH ROW
  EXECUTE FUNCTION public.sync_signal_evidence();

-- Backfill 3 sinyal yang sudah ada supaya signal_evidence langsung terisi
UPDATE public.signals SET evidence = evidence WHERE evidence IS NOT NULL;
