-- ============================================================
-- FIX ROOT CAUSE: default privileges auto-grant EXECUTE ke anon
-- untuk SETIAP fungsi baru yang dibuat (termasuk lewat CREATE OR
-- REPLACE), makanya fix lama kebobol lagi. Cabut default ini.
-- ============================================================
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public REVOKE EXECUTE ON ROUTINES FROM anon;

-- ============================================================
-- FIX KRITIS: fungsi ini memutasi data (invalidate signal,
-- nonaktifkan saham) TANPA cek auth sama sekali, dan bisa
-- dipanggil publik lewat /rest/v1/rpc/. Harusnya cuma cron
-- (service_role/postgres) yang boleh jalankan.
-- ============================================================
REVOKE EXECUTE ON FUNCTION public.process_pending_corporate_actions() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.trigger_process_corporate_actions() FROM anon, authenticated;

-- ============================================================
-- Defense-in-depth: fungsi ini sudah self-check auth/admin di
-- dalam body-nya (raise exception kalau bukan admin/belum login),
-- jadi gak ada kebocoran data, tapi tetap cabut akses anon biar
-- gak bisa dicoba-coba tanpa login sama sekali.
-- ============================================================
REVOKE EXECUTE ON FUNCTION public.get_my_wallet() FROM anon;
REVOKE EXECUTE ON FUNCTION public.refund_token(text, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.request_account_deletion(text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.admin_dashboard_summary() FROM anon;
REVOKE EXECUTE ON FUNCTION public.admin_invalidate_signal(uuid, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.admin_record_corporate_action(uuid, text, date, numeric, text) FROM anon;

-- ============================================================
-- FIX performa: policy duplikat di corporate_actions (ALL vs
-- INSERT/UPDATE/DELETE terpisah yang isinya sama persis)
-- ============================================================
DROP POLICY IF EXISTS "admin_manage_corporate_actions" ON public.corporate_actions;
