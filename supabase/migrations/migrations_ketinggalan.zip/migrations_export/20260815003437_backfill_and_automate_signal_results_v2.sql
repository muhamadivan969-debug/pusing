
CREATE OR REPLACE FUNCTION public.record_signal_result()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE
  v_result text;
  v_exit numeric;
  v_r numeric;
BEGIN
  IF NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;

  CASE NEW.status
    WHEN 'HIT_TP2' THEN v_result := 'WIN'; v_exit := NEW.tp2;
    WHEN 'HIT_SL' THEN v_result := 'LOSS'; v_exit := NEW.stop_loss;
    WHEN 'EXPIRED' THEN v_result := 'BREAKEVEN'; v_exit := NULL;
    WHEN 'INVALIDATED' THEN v_result := 'INVALID'; v_exit := NULL;
    ELSE RETURN NEW;
  END CASE;

  IF v_exit IS NOT NULL AND NEW.entry_price IS NOT NULL AND NEW.stop_loss IS NOT NULL
     AND NEW.entry_price <> NEW.stop_loss THEN
    IF NEW.direction = 'BUY' THEN
      v_r := round((v_exit - NEW.entry_price) / NULLIF(NEW.entry_price - NEW.stop_loss, 0), 2);
    ELSIF NEW.direction = 'SELL' THEN
      v_r := round((NEW.entry_price - v_exit) / NULLIF(NEW.stop_loss - NEW.entry_price, 0), 2);
    END IF;
  END IF;

  INSERT INTO public.signal_results (id, signal_id, result, r_multiple, holding_minutes, evaluated_at)
  VALUES (
    gen_random_uuid(), NEW.id, v_result, v_r,
    CASE WHEN NEW.resolved_at IS NOT NULL AND NEW.created_at IS NOT NULL
      THEN extract(epoch FROM (NEW.resolved_at - NEW.created_at))/60 ELSE NULL END,
    COALESCE(NEW.resolved_at, now())
  )
  ON CONFLICT (signal_id) DO NOTHING;

  RETURN NEW;
END;
$function$;

CREATE TRIGGER trg_record_signal_result
  AFTER UPDATE ON public.signals
  FOR EACH ROW
  EXECUTE FUNCTION public.record_signal_result();

INSERT INTO public.signal_results (id, signal_id, result, r_multiple, holding_minutes, evaluated_at)
SELECT
  gen_random_uuid(), s.id,
  CASE s.status
    WHEN 'HIT_TP2' THEN 'WIN'
    WHEN 'HIT_SL' THEN 'LOSS'
    WHEN 'EXPIRED' THEN 'BREAKEVEN'
    WHEN 'INVALIDATED' THEN 'INVALID'
  END,
  CASE
    WHEN s.status = 'HIT_TP2' AND s.entry_price IS NOT NULL AND s.stop_loss IS NOT NULL AND s.entry_price <> s.stop_loss THEN
      CASE WHEN s.direction = 'BUY' THEN round((s.tp2 - s.entry_price) / NULLIF(s.entry_price - s.stop_loss,0),2)
           WHEN s.direction = 'SELL' THEN round((s.entry_price - s.tp2) / NULLIF(s.stop_loss - s.entry_price,0),2)
      END
    WHEN s.status = 'HIT_SL' THEN -1
    ELSE NULL
  END,
  CASE WHEN s.resolved_at IS NOT NULL AND s.created_at IS NOT NULL
    THEN extract(epoch FROM (s.resolved_at - s.created_at))/60 ELSE NULL END,
  COALESCE(s.resolved_at, s.created_at)
FROM public.signals s
WHERE s.status IN ('HIT_TP2','HIT_SL','EXPIRED','INVALIDATED')
ON CONFLICT (signal_id) DO NOTHING;
