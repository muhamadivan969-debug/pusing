
CREATE OR REPLACE FUNCTION public.trigger_backtest_v11_manual(p_timeframe text DEFAULT 'D1', p_offset int DEFAULT 0, p_max_stocks int DEFAULT 400)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_url text; v_key text; v_secret text; v_req_id bigint;
BEGIN
  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    RAISE EXCEPTION 'secret belum lengkap';
  END IF;
  SELECT net.http_post(
    url := v_url || '/functions/v1/backtest-signals?timeframe=' || p_timeframe || '&offset=' || p_offset || '&max_stocks=' || p_max_stocks,
    headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret)
  ) INTO v_req_id;
  RETURN v_req_id;
END;
$$;
