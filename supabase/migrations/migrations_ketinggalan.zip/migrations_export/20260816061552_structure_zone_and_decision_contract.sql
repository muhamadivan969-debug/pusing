
-- Section 54: Support & Resistance Zone Contract
-- Setiap generate-signals run menghasilkan snapshot zone baru (immutable per section 61,
-- konsisten dgn prinsip "Immutable snapshot menjaga histori tetap dapat diaudit") --
-- bukan record zone yang di-mutate lintas waktu.
create table if not exists structure_zones (
  id uuid primary key default gen_random_uuid(),
  stock_id uuid not null references stocks(id),
  timeframe text not null check (timeframe = any (array['H1','H4','D1','W1'])),
  zone_type text not null check (zone_type = any (array['SUPPORT','RESISTANCE'])),
  price_low numeric not null,
  price_high numeric not null check (price_high >= price_low),
  mid_price numeric generated always as ((price_low + price_high) / 2) stored,
  source_timeframe text not null,
  source_pivot_candle_ids uuid[] not null,
  touch_count int not null default 1 check (touch_count >= 1),
  retest_count int not null default 0 check (retest_count >= 0),
  strength_score numeric not null,
  strength text not null check (strength = any (array['WEAK','MODERATE','STRONG'])),
  age_in_bars int not null default 0 check (age_in_bars >= 0),
  formula_version text not null,
  generated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists idx_structure_zones_stock_tf on structure_zones(stock_id, timeframe, zone_type);
create index if not exists idx_structure_zones_generated_at on structure_zones(generated_at);

-- Section 53.2: Structure Labels (HH/HL/LH/LL/SWING_HIGH/SWING_LOW/SIDEWAYS/UNCLEAR)
create table if not exists structure_labels (
  id uuid primary key default gen_random_uuid(),
  stock_id uuid not null references stocks(id),
  timeframe text not null check (timeframe = any (array['H1','H4','D1','W1'])),
  label text not null check (label = any (array['HH','HL','LH','LL','SWING_HIGH','SWING_LOW','SIDEWAYS','UNCLEAR'])),
  price numeric,
  source_candle_id uuid references candles(id),
  detected_at timestamptz not null default now(),
  formula_version text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_structure_labels_stock_tf on structure_labels(stock_id, timeframe, detected_at desc);

alter table signals
  add column if not exists entry_type text
    check (entry_type is null or entry_type = any (array['AREA','TRIGGER','RETEST','SUPPORT'])),
  add column if not exists trigger_state text
    check (trigger_state is null or trigger_state = any (array[
      'INTRABAR_TOUCH','BREAKOUT_CANDIDATE','BREAKOUT_CONFIRMED','FAILED_BREAKOUT','BREAKOUT_RETEST',
      'BREAKDOWN_CANDIDATE','BREAKDOWN_CONFIRMED','FAILED_BREAKDOWN','BREAKDOWN_RETEST'
    ])),
  add column if not exists overextension_status text
    check (overextension_status is null or overextension_status = any (array['NORMAL','OVEREXTENDED','UNKNOWN'])),
  add column if not exists tp1_reason text,
  add column if not exists tp2_reason text,
  add column if not exists support_zone_id uuid references structure_zones(id),
  add column if not exists resistance_zone_id uuid references structure_zones(id),
  add column if not exists tp1_zone_id uuid references structure_zones(id),
  add column if not exists tp2_zone_id uuid references structure_zones(id);

comment on column signals.entry_type is 'Section 56.2: AREA/TRIGGER/RETEST/SUPPORT - sumber evidence entry';
comment on column signals.trigger_state is 'Section 55: breakout/breakdown state machine snapshot saat signal dibuat';
comment on column signals.overextension_status is 'Section 58: NORMAL/OVEREXTENDED/UNKNOWN, hanya menggerbang BUY';
comment on column signals.tp1_reason is 'Alasan semantik saat tp1 null (setup gagal validasi TP)';
comment on column signals.tp2_reason is 'Section 56.4: reason wajib ada saat tp2 null, mis. NO_VALID_SECOND_RESISTANCE';
