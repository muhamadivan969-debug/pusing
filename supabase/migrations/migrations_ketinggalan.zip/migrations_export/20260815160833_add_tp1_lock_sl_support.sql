alter table public.signals add column if not exists initial_stop_loss numeric;
update public.signals set initial_stop_loss = stop_loss where initial_stop_loss is null;

alter table public.signals drop constraint if exists signals_status_check;
alter table public.signals add constraint signals_status_check
  check (status = ANY (ARRAY['ACTIVE','HIT_TP1','HIT_TP2','HIT_SL','HIT_SL_LOCKED','EXPIRED','INVALIDATED']));
