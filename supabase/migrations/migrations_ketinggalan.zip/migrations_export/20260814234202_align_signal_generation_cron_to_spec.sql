-- Dokumen (poin 9.3 & 14.2) cuma minta 2 event generate signal per hari:
--   Sesi 1 -> 12:10 WIB: generate H1 + H4 (dipakai buat entry sesi 2)
--   Closing -> 15:25 WIB: generate D1 + W1 (acuan utama besok)
-- Implementasi sebelumnya generate H1 tiap jam (09,10,11 WIB) + H4/D1 di jam-jam lain yang
-- tidak match dokumen -> biaya AI/OpenRouter boros dan sinyal tidak sesuai lifecycle yang
-- didokumentasikan (expiry 15:30). Konsolidasi ke jadwal resmi.

select cron.unschedule('signal-pipeline-h1-session1');
select cron.unschedule('signal-pipeline-h1-session2');
select cron.unschedule('signal-pipeline-h4-session1');
select cron.unschedule('signal-pipeline-h4-session2');
select cron.unschedule('signal-pipeline-d1');
select cron.unschedule('signal-pipeline-w1');

-- Sesi 1: 12:10 WIB = 05:10 UTC, Senin-Jumat -> H1 & H4
select cron.schedule('signal-pipeline-h1-sesi1', '10 5 * * 1-5', $$SELECT public.trigger_signal_pipeline('H1');$$);
select cron.schedule('signal-pipeline-h4-sesi1', '10 5 * * 1-5', $$SELECT public.trigger_signal_pipeline('H4');$$);

-- Closing: 15:25 WIB = 08:25 UTC, Senin-Jumat -> D1 (harian) & W1 (Jumat saja, karena mingguan)
select cron.schedule('signal-pipeline-d1-closing', '25 8 * * 1-5', $$SELECT public.trigger_signal_pipeline('D1');$$);
select cron.schedule('signal-pipeline-w1-closing', '25 8 * * 5', $$SELECT public.trigger_signal_pipeline('W1');$$);
