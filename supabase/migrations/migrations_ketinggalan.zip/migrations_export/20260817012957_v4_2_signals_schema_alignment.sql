-- Spec v4.2 Section 18.2: signal traceability columns yang belum ada
ALTER TABLE public.signals
  ADD COLUMN IF NOT EXISTS effective_at timestamptz,
  ADD COLUMN IF NOT EXISTS schema_version text DEFAULT 'v1',
  ADD COLUMN IF NOT EXISTS data_snapshot_id uuid;

COMMENT ON COLUMN public.signals.effective_at IS 'Section 8.4/8.5 spec v4.2: kapan sinyal mulai berlaku (sesi perdagangan berikutnya), beda dari triggered_at (waktu generate).';
COMMENT ON COLUMN public.signals.schema_version IS 'Section 25.2 spec v4.2: versi schema signal untuk release traceability.';
COMMENT ON COLUMN public.signals.data_snapshot_id IS 'Section 18.2 spec v4.2: referensi snapshot data pasar yang dipakai saat generate sinyal ini.';

-- Section 3.2: data_source harus IDX (primary) atau YAHOO_FALLBACK, bukan default ke fallback
ALTER TABLE public.signals ALTER COLUMN data_source SET DEFAULT 'IDX';
ALTER TABLE public.signals DROP CONSTRAINT IF EXISTS signals_data_source_check;
ALTER TABLE public.signals ADD CONSTRAINT signals_data_source_check
  CHECK (data_source IS NULL OR data_source IN ('IDX', 'YAHOO_FALLBACK'));

-- Update comment signal_tier: v4.2 menghapus H1/H4 dari engine (Daily = D1 saja, bukan H1/H4/D1)
COMMENT ON COLUMN public.signals.signal_tier IS 'daily = evaluasi D1 saja (spec v4.2 section 5.2, H1/H4 dihapus dari engine). swing = D1+W1 confluence, holding beberapa minggu.';
COMMENT ON COLUMN public.signals.confirm_timeframe IS 'timeframe konfirmasi struktur menengah -- NULL untuk daily & swing sejak v4.2 (H1/H4 dihapus, tidak ada tahap confirm terpisah).';
COMMENT ON COLUMN public.signals.entry_timeframe IS 'timeframe timing entry -- D1 untuk daily & swing sejak v4.2 (sebelumnya H1 untuk daily, sudah dihapus).';
