-- 1) Trigger ini nulis ke kolom gate_passed yang sudah tidak ada di
--    signals -- kalau dibiarkan, setiap INSERT baru dari
--    generate-signals-mtf akan GAGAL. Drop trigger + function-nya.
drop trigger if exists trg_set_signal_gate_passed on public.signals;
drop function if exists public.set_signal_gate_passed();

-- 2) get_signal_history_stats menghitung & mengembalikan Win Rate agregat
--    ke frontend (riwayat-sinyal) -- persis yang harus dihapus sesuai
--    keputusan produk baru (Win Rate dihapus total dari tampilan user).
--    Juga rujuk sg.gate_passed yang sudah tidak ada.
drop function if exists public.get_signal_history_stats(integer);

-- 3) calculate_trending_scores (Worker 3, badge Trending di Screener)
--    pakai confidence_score sbg 40% bobot skor -- kolom sudah tidak ada.
--    Ganti komponen itu jadi 0 (netral), sisa bobot lain (RSI/MACD/Volume/
--    Fundamental) tetap jalan seperti biasa. Trending badge != Win Rate
--    di Kartu Sinyal, jadi fitur ini tetap dipertahankan.
create or replace function public.calculate_trending_scores()
returns void
language plpgsql
security definer
set search_path to 'public'
as $function$
BEGIN
  WITH latest_indicator AS (
    SELECT DISTINCT ON (stock_id) stock_id, rsi14, macd_hist, volume_avg20
    FROM public.indicators
    WHERE timeframe = 'D1'
    ORDER BY stock_id, updated_at DESC
  ),
  scored AS (
    SELECT
      s.id AS stock_id,
      -- RSI healthy momentum zone (0-10)
      CASE WHEN li.rsi14 BETWEEN 50 AND 70 THEN 10 ELSE 0 END
      -- MACD bullish histogram (0-10)
      + CASE WHEN li.macd_hist > 0 THEN 10 ELSE 0 END
      -- Volume spike vs 20d avg (0-15)
      + CASE
          WHEN li.volume_avg20 > 0 AND q.volume >= li.volume_avg20 * 2 THEN 15
          WHEN li.volume_avg20 > 0 AND q.volume >= li.volume_avg20 * 1.5 THEN 8
          ELSE 0
        END
      -- Fundamental: reasonable PE (0-10)
      + CASE WHEN f.pe_ratio IS NOT NULL AND f.pe_ratio BETWEEN 0 AND 25 THEN 10 ELSE 0 END
      -- Fundamental: profitable (0-10)
      + CASE WHEN f.net_profit IS NOT NULL AND f.net_profit > 0 THEN 10 ELSE 0 END
      AS score
    FROM public.stocks s
    LEFT JOIN latest_indicator li ON li.stock_id = s.id
    LEFT JOIN public.quotes q ON q.stock_id = s.id
    LEFT JOIN public.fundamentals f ON f.stock_id = s.id
    WHERE s.is_active = true
  )
  UPDATE public.stocks st
  SET trending_score = round(sc.score, 1),
      trending_label = CASE WHEN sc.score >= 60 THEN 'Trending' ELSE NULL END,
      trending_updated_at = now()
  FROM scored sc
  WHERE sc.stock_id = st.id;
END;
$function$;