
CREATE OR REPLACE FUNCTION public.get_signal_history_stats(p_days integer DEFAULT NULL::integer)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_total integer;
  v_wins integer;
  v_losses integer;
  v_breakeven integer;
  v_avg_r numeric;
  v_win_rate numeric;
BEGIN
  SELECT
    count(*) FILTER (WHERE sr.result IN ('WIN','LOSS','BREAKEVEN')),
    count(*) FILTER (WHERE sr.result = 'WIN'),
    count(*) FILTER (WHERE sr.result = 'LOSS'),
    count(*) FILTER (WHERE sr.result = 'BREAKEVEN'),
    avg(sr.r_multiple) FILTER (WHERE sr.result IN ('WIN','LOSS','BREAKEVEN'))
  INTO v_total, v_wins, v_losses, v_breakeven, v_avg_r
  FROM public.signal_results sr
  JOIN public.signals sg ON sg.id = sr.signal_id
  WHERE sg.gate_passed = true
    AND (p_days IS NULL OR sg.created_at >= now() - (p_days || ' days')::interval);

  v_win_rate := CASE WHEN v_total > 0 THEN round((v_wins::numeric / v_total) * 100, 1) ELSE NULL END;

  RETURN jsonb_build_object(
    'total_trades', COALESCE(v_total, 0),
    'wins', COALESCE(v_wins, 0),
    'losses', COALESCE(v_losses, 0),
    'breakeven', COALESCE(v_breakeven, 0),
    'win_rate', v_win_rate,
    'avg_r', round(COALESCE(v_avg_r, 0), 2)
  );
END;
$function$;
