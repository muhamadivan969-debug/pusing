CREATE POLICY mtf_pipeline_runs_admin_select ON public.mtf_pipeline_runs
  FOR SELECT
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.is_admin = true));