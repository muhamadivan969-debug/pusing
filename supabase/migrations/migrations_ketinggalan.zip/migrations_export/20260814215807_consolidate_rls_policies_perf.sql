
-- Fix RLS init-plan perf warning on policy I created earlier
DROP POLICY IF EXISTS ad_verifications_owner_read ON public.ad_verifications;
CREATE POLICY ad_verifications_owner_read ON public.ad_verifications
  FOR SELECT TO authenticated USING (user_id = (select auth.uid()));

-- Fix same issue on corporate_actions_admin_write (uses auth.uid() unwrapped)
DROP POLICY IF EXISTS corporate_actions_admin_write ON public.corporate_actions;
CREATE POLICY corporate_actions_admin_write ON public.corporate_actions
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = (select auth.uid()) AND profiles.is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = (select auth.uid()) AND profiles.is_admin = true));

-- Drop literal duplicate admin-read policies (same logic, two different implementations stacked)
DROP POLICY IF EXISTS "admin read audit_logs" ON public.audit_logs;
DROP POLICY IF EXISTS "admin read job_runs" ON public.job_runs;
DROP POLICY IF EXISTS "admin read provider_health" ON public.provider_health;

-- Consolidate admin+own SELECT policies (2 policies -> 1, same access, faster eval)
DROP POLICY IF EXISTS admin_select_all_app_ratings ON public.app_ratings;
DROP POLICY IF EXISTS "own rating select" ON public.app_ratings;
CREATE POLICY app_ratings_select ON public.app_ratings
  FOR SELECT TO authenticated
  USING (is_current_user_admin() OR (select auth.uid()) = user_id);

DROP POLICY IF EXISTS admin_select_all_bug_reports ON public.bug_reports;
DROP POLICY IF EXISTS "own bug reports select" ON public.bug_reports;
CREATE POLICY bug_reports_select ON public.bug_reports
  FOR SELECT TO authenticated
  USING (is_current_user_admin() OR (select auth.uid()) = user_id);

DROP POLICY IF EXISTS admin_select_all_feature_requests ON public.feature_requests;
DROP POLICY IF EXISTS "own feature requests select" ON public.feature_requests;
CREATE POLICY feature_requests_select ON public.feature_requests
  FOR SELECT TO authenticated
  USING (is_current_user_admin() OR (select auth.uid()) = user_id);

DROP POLICY IF EXISTS admin_select_all_payments ON public.payments;
DROP POLICY IF EXISTS "own payments read" ON public.payments;
CREATE POLICY payments_select ON public.payments
  FOR SELECT TO authenticated
  USING (is_current_user_admin() OR (select auth.uid()) = user_id);

DROP POLICY IF EXISTS admin_select_all_subscriptions ON public.subscriptions;
DROP POLICY IF EXISTS "own subscriptions read" ON public.subscriptions;
CREATE POLICY subscriptions_select ON public.subscriptions
  FOR SELECT TO authenticated
  USING (is_current_user_admin() OR (select auth.uid()) = user_id);
