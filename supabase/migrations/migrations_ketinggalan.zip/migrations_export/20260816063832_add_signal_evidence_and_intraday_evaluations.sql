
-- section 25: evidence schema sbg snapshot immutable terpisah, jaga histori kalau ada revisi
create table if not exists public.signal_evidence (
  id uuid primary key default gen_random_uuid(),
  signal_id uuid not null references public.signals(id) on delete cascade,
  structure jsonb,
  support jsonb,
  resistance jsonb,
  trigger jsonb,
  invalidation jsonb,
  timeframes jsonb,
  data_quality jsonb,
  formula_version text,
  generated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists idx_signal_evidence_signal_id on public.signal_evidence(signal_id);

alter table public.signal_evidence enable row level security;

create policy "signal_evidence readable by all"
on public.signal_evidence for select to public using (true);

-- backfill dari kolom signals.evidence yang sudah ada (jsonb inline) biar histori lama tetap kebaca
insert into public.signal_evidence (signal_id, structure, support, resistance, trigger, invalidation, timeframes, data_quality, formula_version, generated_at)
select id,
  evidence->'structure', evidence->'support', evidence->'resistance', evidence->'trigger',
  evidence->'invalidation', evidence->'timeframes', evidence->'data_quality',
  formula_version, coalesce(created_at, now())
from public.signals
where evidence is not null
on conflict do nothing;

-- section 75 GOLDEN-016 (same-candle TP/SL ambiguity) & lifecycle evaluation per timeframe candle
create table if not exists public.intraday_evaluations (
  id uuid primary key default gen_random_uuid(),
  signal_id uuid not null references public.signals(id) on delete cascade,
  candle_id uuid references public.candles(id),
  checked_at timestamptz not null default now(),
  price_high numeric,
  price_low numeric,
  hit_tp1 boolean default false,
  hit_tp2 boolean default false,
  hit_sl boolean default false,
  ambiguous_same_candle boolean default false,
  resolution_rule text,
  created_at timestamptz not null default now()
);

create index if not exists idx_intraday_evaluations_signal_id on public.intraday_evaluations(signal_id);

alter table public.intraday_evaluations enable row level security;

create policy "intraday_evaluations readable by all"
on public.intraday_evaluations for select to public using (true);
