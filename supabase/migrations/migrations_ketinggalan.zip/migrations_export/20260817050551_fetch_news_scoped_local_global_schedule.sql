-- Fungsi baru: trigger_fetch_news(scope) supaya lokal & global bisa dipanggil terpisah
create or replace function public.trigger_fetch_news(p_scope text default 'all')
returns void
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_url text; v_key text; v_run_id uuid; v_req_id bigint;
begin
  v_run_id := public.job_run_start('fetch-news-' || p_scope);
  select decrypted_secret into v_url from vault.decrypted_secrets where name = 'project_url';
  select decrypted_secret into v_key from vault.decrypted_secrets where name = 'service_role_key';
  if v_url is null or v_key is null then
    perform public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason','vault secrets belum diset'));
    return;
  end if;
  select net.http_post(
    url := v_url || '/functions/v1/fetch-news?scope=' || p_scope,
    headers := jsonb_build_object('Authorization','Bearer ' || v_key,'Content-Type','application/json'),
    timeout_milliseconds := 120000
  ) into v_req_id;
  perform public.job_run_finish(v_run_id, 'SUCCESS', jsonb_build_object('net_request_id', v_req_id, 'note','dispatched, menunggu reconcile'));
end;
$function$;

-- Hapus jadwal lama yang gabung lokal+global cuma 2x sehari
select cron.unschedule('fetch-news-morning');
select cron.unschedule('fetch-news-afternoon');

-- Lokal: gratis, no limit -> tiap 5 menit
select cron.schedule(
  'fetch-news-local',
  '*/5 * * * *',
  $$select public.trigger_fetch_news('local');$$
);

-- Global (GNews): limit 100 request/hari -> tiap 3 jam (8x/hari, aman dari limit)
select cron.schedule(
  'fetch-news-global',
  '0 */3 * * *',
  $$select public.trigger_fetch_news('global');$$
);
