
update public.corporate_actions
set status = 'PROCESSED', processed_at = now(), ex_date = '2026-07-30',
    notes = notes || ' | Dikonfirmasi: BEI Peng-DEL-00002/BEI.PP1/07-2026, efektif 30 Juli 2026.'
where stock_id = (select id from public.stocks where ticker='CNTX')
  and action_type='DELISTING' and status='PENDING';

update public.stocks set is_active = false where ticker = 'CNTX';

insert into public.audit_logs (actor_id, action, entity_type, entity_id, detail)
select null, 'AUDIT_MARK_DELISTED', 'stock', id,
  jsonb_build_object('ticker', 'CNTX', 'reason', 'Konfirmasi delisting BEI 30 Juli 2026 via web search')
from public.stocks where ticker='CNTX';
