-- GAP: RLS trading_plans cuma cek kepemilikan (user_id), tidak ada penegakan bahwa
-- user Free cuma boleh edit module_1..module_3 (spec 5.13/8.4). Free user bisa PATCH
-- module_4..module_10 langsung lewat REST API walau UI mengunci tampilannya.
-- Fix: trigger yang menolak perubahan module_4..module_10 kalau user belum premium.

create or replace function public.enforce_trading_plan_module_lock()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_is_premium boolean;
begin
  select coalesce(is_premium, false) into v_is_premium
  from public.profiles where id = new.user_id;

  if not v_is_premium then
    if new.module_4  is distinct from old.module_4  or
       new.module_5  is distinct from old.module_5  or
       new.module_6  is distinct from old.module_6  or
       new.module_7  is distinct from old.module_7  or
       new.module_8  is distinct from old.module_8  or
       new.module_9  is distinct from old.module_9  or
       new.module_10 is distinct from old.module_10 then
      raise exception 'MODUL_TERKUNCI: modul 4-10 hanya untuk Premium';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_enforce_trading_plan_module_lock on public.trading_plans;
create trigger trg_enforce_trading_plan_module_lock
before update on public.trading_plans
for each row
execute function public.enforce_trading_plan_module_lock();

-- Juga cegah insert awal langsung mengisi modul 4-10 buat user Free.
create or replace function public.enforce_trading_plan_module_lock_insert()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_is_premium boolean;
begin
  select coalesce(is_premium, false) into v_is_premium
  from public.profiles where id = new.user_id;

  if not v_is_premium then
    if new.module_4 is not null or new.module_5 is not null or new.module_6 is not null or
       new.module_7 is not null or new.module_8 is not null or new.module_9 is not null or
       new.module_10 is not null then
      raise exception 'MODUL_TERKUNCI: modul 4-10 hanya untuk Premium';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_enforce_trading_plan_module_lock_insert on public.trading_plans;
create trigger trg_enforce_trading_plan_module_lock_insert
before insert on public.trading_plans
for each row
execute function public.enforce_trading_plan_module_lock_insert();
