-- Perbaikan: trigger cron sebelumnya tidak mengirim header x-worker-secret,
-- padahal function-nya (fetch-earnings-calendar, fetch-ipo-calendar,
-- fetch-fundamentals, generate-trending-reason) mewajibkan header itu untuk
-- otorisasi. Tanpa header ini, function selalu balas 401 saat dipanggil cron.

CREATE OR REPLACE FUNCTION public.trigger_fetch_earnings_calendar()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_url text; v_key text; v_secret text;
BEGIN
  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    RAISE WARNING 'fetch-earnings-calendar: secret belum lengkap'; RETURN;
  END IF;
  PERFORM net.http_post(
    url := v_url || '/functions/v1/fetch-earnings-calendar',
    headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret)
  );
END; $$;

CREATE OR REPLACE FUNCTION public.trigger_fetch_ipo_calendar()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_url text; v_key text; v_secret text;
BEGIN
  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    RAISE WARNING 'fetch-ipo-calendar: secret belum lengkap'; RETURN;
  END IF;
  PERFORM net.http_post(
    url := v_url || '/functions/v1/fetch-ipo-calendar',
    headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret)
  );
END; $$;

CREATE OR REPLACE FUNCTION public.trigger_fetch_fundamentals()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_url text; v_key text; v_secret text;
BEGIN
  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    RAISE WARNING 'fetch-fundamentals: secret belum lengkap'; RETURN;
  END IF;
  PERFORM net.http_post(
    url := v_url || '/functions/v1/fetch-fundamentals',
    headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret)
  );
END; $$;

CREATE OR REPLACE FUNCTION public.trigger_fetch_economic_calendar()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_url text; v_key text; v_secret text;
BEGIN
  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';
  IF v_url IS NULL OR v_key IS NULL OR v_secret IS NULL THEN
    RAISE WARNING 'fetch-economic-calendar: secret belum lengkap'; RETURN;
  END IF;
  PERFORM net.http_post(
    url := v_url || '/functions/v1/fetch-economic-calendar',
    headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret)
  );
END; $$;