
-- BUG: trigger_signal_pipeline_mtf() memanggil fetch-candles, compute-indicators, dan
-- generate-signals-mtf TANPA parameter limit. Ketiga edge function itu punya default
-- limit kecil (50/300/300), jadi pipeline hanya pernah memproses sebagian kecil dari
-- 948 saham aktif (alfabetis dari awal). Fix: kirim limit=1000 eksplisit di setiap
-- panggilan supaya seluruh universe saham aktif ke-cover dalam satu call.
CREATE OR REPLACE FUNCTION public.trigger_signal_pipeline_mtf(p_tier text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_url text;
  v_key text;
  v_secret text;
  v_headers jsonb;
  v_run_id uuid;
  v_req bigint;
  v_res jsonb;
  v_timeframes text[];
  v_tf text;
BEGIN
  v_run_id := public.job_run_start('signal-pipeline-mtf-' || p_tier);

  IF p_tier = 'daily' THEN
    v_timeframes := ARRAY['H1','H4','D1'];
  ELSIF p_tier = 'swing' THEN
    v_timeframes := ARRAY['D1','W1'];
  ELSE
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'tier tidak dikenal: ' || p_tier));
    RETURN;
  END IF;

  SELECT decrypted_secret INTO v_url FROM vault.decrypted_secrets WHERE name = 'project_url';
  SELECT decrypted_secret INTO v_key FROM vault.decrypted_secrets WHERE name = 'service_role_key';
  SELECT value INTO v_secret FROM public.internal_secrets WHERE key = 'worker_shared_secret';

  IF v_url IS NULL OR v_key IS NULL THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('reason', 'vault secrets belum diset'));
    RETURN;
  END IF;

  v_headers := jsonb_build_object('Authorization', 'Bearer ' || v_key, 'Content-Type', 'application/json', 'x-worker-secret', v_secret);

  -- Tahap 1-2 per timeframe: fetch-candles lalu compute-indicators, limit=1000 supaya
  -- seluruh saham aktif (948) ke-cover dalam satu call (bukan cuma default 50/300).
  FOREACH v_tf IN ARRAY v_timeframes LOOP
    SELECT net.http_post(url := v_url || '/functions/v1/fetch-candles?timeframe=' || v_tf || '&limit=1000', headers := v_headers, timeout_milliseconds := 240000) INTO v_req;
    v_res := public.wait_for_net_response(v_req, 220);
    IF NOT (v_res->>'ok')::boolean THEN
      PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'fetch-candles', 'timeframe', v_tf, 'result', v_res));
      RETURN;
    END IF;

    SELECT net.http_post(url := v_url || '/functions/v1/compute-indicators?timeframe=' || v_tf || '&limit=1000', headers := v_headers, timeout_milliseconds := 240000) INTO v_req;
    v_res := public.wait_for_net_response(v_req, 220);
    IF NOT (v_res->>'ok')::boolean THEN
      PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'compute-indicators', 'timeframe', v_tf, 'result', v_res));
      RETURN;
    END IF;
  END LOOP;

  -- Tahap 3: generate-signals-mtf, sekali untuk seluruh tier, limit=1000 juga.
  SELECT net.http_post(url := v_url || '/functions/v1/generate-signals-mtf?tier=' || p_tier || '&limit=1000', headers := v_headers, timeout_milliseconds := 240000) INTO v_req;
  v_res := public.wait_for_net_response(v_req, 220);
  IF NOT (v_res->>'ok')::boolean THEN
    PERFORM public.job_run_finish(v_run_id, 'ERROR', jsonb_build_object('stage', 'generate-signals-mtf', 'result', v_res));
    RETURN;
  END IF;

  PERFORM public.job_run_finish(v_run_id, 'SUCCESS', jsonb_build_object(
    'note', 'fetch-candles+compute-indicators (' || array_to_string(v_timeframes, ',') || ') -> generate-signals-mtf selesai (full universe, limit=1000)',
    'tier', p_tier,
    'generate_signals_mtf_result', v_res
  ));
END;
$function$
